var myLayout;
var AppUtils = {
	doPost: function (url, jsonData, successCallBack, errorCallBack) {
		$.ajax({
			url: url,
			type: "POST",
			dataType: "json",
			contentType: 'application/json;charset=UTF-8',
			data: JSON.stringify(jsonData),
			success: function (data) {
				if (data.success) {
					if (successCallBack) {
						successCallBack(data);
					}
				}
			},
			error: function (error) {
				var status = error.status;
				if (status == 200) {
					//todo
				} else if (status == 404) {
					AppUtils.alert(url + '没有找到');
				} else if (status == 500) {
					AppUtils.alert('系统异常，请联系管理员');
				} else {
					//AppUtils.alert('系统异常，请联系管理员');
					//window.location.href=ctx+'/sys/home/index';
				}
				if (errorCallBack) {
					errorCallBack(error);
				}
			}
		});
	},

	doSyncPost: function (url, jsonData, successCallBack, errorCallBack) {
		$.ajax({
			url: url,
			async: false,
			type: "POST",
			dataType: "json",
			contentType: 'application/json;charset=UTF-8',
			data: JSON.stringify(jsonData),
			success: function (data) {
				if (data.success) {
					if (successCallBack) {
						successCallBack(data);
					}
				} else {
					var errObject = data.errObject;
					if (errObject.errCode == 'not_login') {
						//系统没有登录,拦截ajax请求后的响应
						window.location.href = '/sys/login';
					} else if (errObject.errCode == 'unauthorized') {
						//系统没有权限,拦截ajax请求后的响应
						window.location.href = '/sys/unauthorized';
					} else {
						//已经登陆,按照不同的业务的错误提示进行提示
						AppUtils.alert(errObject.errMess);
					}
				}
			},
			error: function (error) {
				var status = error.status;
				if (status == 200) {
					//todo
				} else if (status == 404) {
					AppUtils.alert(url + '没有找到');
				} else if (status == 500) {
					AppUtils.alert('系统异常，请联系管理员');
				} else {
					//AppUtils.alert('系统异常，请联系管理员');
					//window.location.href=ctx+'/sys/home/index';
				}
				if (errorCallBack) {
					errorCallBack(error);
				}
			}
		});
	},
	alert:function(msg,callBack){
		noefunc.modifyAlert(msg,'确定',false,function(){
			if(callBack){
				callBack();
			}
		},null);
	},
}