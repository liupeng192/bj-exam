$(function(){
	$('.btn_button').click(function () {
		if($(".codelogin").is(":hidden")){
			if ($('#userName').val() == "") {
               AppUtils.alert("请输入手机号或邮箱");
				return false;
			}

		}
		if($(".passlogin").is(":hidden")){
			if ($('#tellcode').val() == "") {
				AppUtils.alert("请输入手机号");
				return false;
			}

		}

	})

	// 验证码登录change密码登录
	$('.change_passlogin').click(function(){
		$('.codelogin').hide();
		$('.passlogin').show();
	})

	// 密码登录change验证码登录
	$('.change_codelogin').click(function(){
		$('.codelogin').show();
		$('.passlogin').hide();
	})

	// 点击获取验证码弹出拼图验证
	$('.sendBtn').click(function(){
		$('p.text').remove();
		var nuber =  /^1\d{10}$/;
    	var tel = document.getElementById('tell').value;
		if (nuber.test(tel)==false) {
			$('.tell').append('<p class="text"><i></i>请输入正确手机号</p>')
	      	return false;
	    }else{
			$('.cover').show();
		}
		
		// 校验验证码错误的提示样式
		// $('.tellcode').append('<p class="text"><i></i>验证码错误</p>')
		// $('#tellcode').addClass('code_border')
	})

	// 获取浏览器宽高度，保持局中国
		var _width = $(window).width();
		var _height = $(window).height();
		var n_width =_width/5-30;
		var n_height =_height/4-40;
		if(_width >=1024){
			$('.course_main').css({'top':n_height,'left':n_width})
		}else{
			$('.course_main').css({'top':'inherit','left':'inherit'})
		}

	// 课程选中
	$('.con ul li').eq(0).addClass('active')
	$('.con ul li').click(function(){
		$(this).addClass("active").siblings().removeClass("active");
		console.log('先点中效果')
		// 取页面中选中的人名以及编号
		var str =$('.con ul li.active strong').text()
		var span =$('.con ul li.active span').text()
		alert('选中名称:'+str+'&&&'+'选中编号：'+span)
		console.log('打印点中内容')
	})

	// 关闭课程
	$('.close').click(function(){
		$('.course_main').hide();
		$('.course_detail').hide();
		$('.cover').hide();
	})

	// 点击保存，取消按钮
	$('.keep').click(function(){
		var userName =$('.con ul li.active strong').text()
		var stucode =$('.con ul li.active span').text()
		var userId = $('#userId').val();
		var state = $('#state').val();
		window.location.href=localhostPaht+"/code/confirmCode?userName="+userName+"&stucode="+stucode+"&userId="+userId+"&state="+state;
	})
	$('.remove').click(function(){
		AppUtils.alert('开始处理点击取消后的操作');
		window.location.href="index.html";
	})
	
});