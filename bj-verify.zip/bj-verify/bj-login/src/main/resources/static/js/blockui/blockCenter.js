$.fn.center = function () {
    this.css("position","Fixed");
    this.css("top", ($(window).height() - this.height() ) / 2);
    this.css("left", ( $(window).width() - this.width() ) / 2);
    var dragbar=this.find('.zx-diaTit').eq(0);
    dragbar.on('mousedown',function(e){
    	 var distenceX = e.clientX;
		 var distenceY = e.clientY;
        $(".zx-diaTit").eq(0).on('mousemove',function(e){
        	 var movex=e.clientX-distenceX;
             var movey=e.clientY-distenceY;
             console.info("movex:"+movex+","+"movey:"+movey);
             if(movex!=0 || movey!=0)  {
            	 var l=(($(window).width() - dragbar.parent().parent().width() ) / 2) + movex;
    		 	 var t=(($(window).height() - dragbar.parent().parent().height()  )  / 2) + movey;
    		 	 var maxL=$(window).width()-dragbar.parent().parent().outerWidth();
    		 	 var maxT=$(window).height()-dragbar.parent().parent().outerHeight();
    		 	 l=l<0 ? 0:l;
    		 	 l=l>maxL ? maxL:l;
    		 	 t=t<0 ? 0:t;
    		 	 t=t>maxT ? maxT:t;
    		 	 dragbar.parent().parent().css('left',l);
    		 	 dragbar.parent().parent().css('top',t);
             }
		 })
         $(document).on('mouseup',function(){
         	$(".zx-diaTit").eq(0).off("mousemove");
         })
         return false;
    })
    return this;
}
