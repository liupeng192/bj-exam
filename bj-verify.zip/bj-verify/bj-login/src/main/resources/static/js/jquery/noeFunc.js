/**
 * 华宾专属js，其他人勿动，切记切记
 */
var noefunc={
	//从func.js中提取，为解决日期控件冲突
		//模拟弹框1 info：提示信息    suretext：确认框文字  canceltext：true or false     
		modifyAlert:function(info,suretext,canceltext,callBack,closeCallBack){
		   	   if($('#note')){
		   	   	  $('#note').remove();
		   	   }
		   	   var str='';
		   	   if(canceltext){
		   	   	 str='<a class="btn btn-e">取消</a>';
		   	   }else{
		   	   	 str='';
		   	   }
		   	   var cont='<div id="note" class="hd-dialog"><div class="hd-warnCont">'+info+'</div><div class="btn-block"><a class="btn btn-o">'+suretext+'</a>'+str+'</div></div>';
		   	   $(cont).appendTo('body');
		   	   $.blockUI({ 
			   			message: $('#note'),
			   			css: { 
			   				width: '380px',
			   			    border:'1px solid #a6c9e2',
			   			    textAlign:'left'
			   		    },
			   		    onBlock: function() {
			   		    	if(callBack){
			   		    		//callBack();
			   		    	}
			            } 
				});
			   $('.blockUI.blockMsg').center();
		       $('.btn-o').click(function(){
		           $.unblockUI({  
		               onUnblock : function(){ 
		            	   if(callBack){
			   		    		callBack();
			   		       }
		            	   if($('#note')){
		            		   $('#note').remove();
		            	   }
		               }  
		           });
		       });
		       $('.btn-e').click(function(){
		           $.unblockUI({
		        	   onUnblock : function(){ 
		        		   if(closeCallBack){
		            		   closeCallBack();
		            	   }
		            	   if($('#note')){
		            		   $('#note').remove();
		            	   }
		               }
		           });
		       });
		   	   
		   },
}
