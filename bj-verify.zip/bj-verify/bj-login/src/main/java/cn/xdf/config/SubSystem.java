package cn.xdf.config;

import java.io.Serializable;
import java.util.Date;

/**
 * @author liupeng
 * @date 2020/7/31-16:00
 **/
public class SubSystem implements Serializable {
    private String id;
    private String name;
    private String baseUrl;
    private String homeUrl;
    private String innerAddress;

    public Date noticeTimeout(String toke, int timeOut)
    {
        return new Date();
    }

    public void noticeShutDown() {}

    public void noticeLoginOut(String token) {}

    public String getHomeUrl()
    {
        return this.baseUrl + this.homeUrl;
    }

    public void setHomeUrl(String homeUrl)
    {
        this.homeUrl = homeUrl;
    }

    public String getId()
    {
        return this.id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getName()
    {
        return this.name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getBaseUrl()
    {
        return this.baseUrl;
    }

    public void setBaseUrl(String baseUrl)
    {
        this.baseUrl = baseUrl;
    }

    public String getInnerAddress()
    {
        return this.innerAddress;
    }

    public void setInnerAddress(String innerAddress)
    {
        this.innerAddress = innerAddress;
    }
}
