package cn.xdf.code.bean;

import cn.xdf.framework.annotation.Column;
import cn.xdf.framework.annotation.Id;
import cn.xdf.framework.annotation.Table;

import java.util.Date;

/**
 * @author liupeng
 * @date 2020/7/31-17:37
 **/

@Table(name="bj_tb_confirm_code")
public class ConfirmCode
{
    @Id
    @Column(name="id")
    private String confirID;
    private String userId;
    private String userName;
    private String stuCode;
    private Date confirmTime;

    public String getConfirID()
    {
        return this.confirID;
    }

    public void setConfirID(String confirID)
    {
        this.confirID = confirID;
    }

    public String getUserId()
    {
        return this.userId;
    }

    public void setUserId(String userId)
    {
        this.userId = userId;
    }

    public String getUserName()
    {
        return this.userName;
    }

    public void setUserName(String userName)
    {
        this.userName = userName;
    }

    public String getStuCode()
    {
        return this.stuCode;
    }

    public void setStuCode(String stuCode)
    {
        this.stuCode = stuCode;
    }

    public Date getConfirmTime()
    {
        return this.confirmTime;
    }

    public void setConfirmTime(Date confirmTime)
    {
        this.confirmTime = confirmTime;
    }
}
