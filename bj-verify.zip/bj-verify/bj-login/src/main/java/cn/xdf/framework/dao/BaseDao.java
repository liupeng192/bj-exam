package cn.xdf.framework.dao;

import cn.xdf.framework.annotation.Column;
import cn.xdf.framework.annotation.Id;
import cn.xdf.framework.annotation.NotDBColumn;
import cn.xdf.framework.annotation.Table;
import cn.xdf.framework.assist.Condition;
import cn.xdf.framework.assist.Order;
import cn.xdf.framework.assist.Pager;
import cn.xdf.framework.assist.QueryResult;
import cn.xdf.framework.utils.RowMapperUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.ConnectionCallback;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import javax.annotation.Resource;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class BaseDao<T> {

	/** 设置一些操作的常量 */
	private static final String SQL_INSERT = "INSERT";
	private static final String SQL_UPDATE = "UPDATE";
	private static final String SQL_DELETE = "DELETE";

	@Resource(name = "jdbcTemplate")
	JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}
	
	private Class<?> entityClass;
	private String tableName;
	private String IDName;
	private int IDIndex;

	@SuppressWarnings("unchecked")
	public BaseDao() {
		if (entityClass == null) {
			if (getClass().getGenericSuperclass() instanceof ParameterizedType) {
				entityClass = (Class<T>) ((ParameterizedType) getClass().getGenericSuperclass())
						.getActualTypeArguments()[0];
			} else {
				entityClass = (Class<T>) ((ParameterizedType) getClass().getSuperclass().getGenericSuperclass())
						.getActualTypeArguments()[0];
			}
		}
		Table table = entityClass.getAnnotation(Table.class);
		if (table != null && StringUtils.isNoneBlank(table.name())) {
			tableName = table.name();
		} else {
			tableName = entityClass.getSimpleName();
		}

		Field[] fields = getDBFields(entityClass.getDeclaredFields());
		boolean checkIDFlag = false;
		for (int i = 0; i < fields.length; i++) {
			fields[i].setAccessible(true);
			Id id = fields[i].getAnnotation(Id.class);
			if (id != null) {
				checkIDFlag = true;
				IDIndex = i;
				Column column = fields[i].getAnnotation(Column.class);
				if (column != null && StringUtils.isNoneBlank(column.name())) {
					IDName = column.name();
				} else {
					IDName = fields[i].getName();
				}
			}
		}
		if (!checkIDFlag) {
			throw new RuntimeException(entityClass.getName() + "$$$没有标注@Id");
		}
	}

	public int save(T entity) {

		String sql = this.makeSql(SQL_INSERT);
		Object[] args = this.setArgs(entity, SQL_INSERT);
		int[] argTypes = this.setArgTypes(entity, SQL_INSERT);
		return jdbcTemplate.update(sql, args, argTypes);
	}

	public int[] batchSave(List<T> list) {

		if (list == null || list.size() == 0) {
			return null;
		}
		String sql = this.makeSql(SQL_INSERT);
		List<Object[]> batchArgs = new ArrayList<Object[]>();
		for (T t : list) {
			Object[] args = this.setArgs(t, SQL_INSERT);
			batchArgs.add(args);
		}
		return jdbcTemplate.batchUpdate(sql, batchArgs);
	}

	public int update(T entity) {

		String sql = this.makeSql(SQL_UPDATE);
		Object[] args = this.setArgs(entity, SQL_UPDATE);
		int[] argTypes = this.setArgTypes(entity, SQL_UPDATE);
		return jdbcTemplate.update(sql, args, argTypes);
	}

	public int updateBySql(String sql) {

		return jdbcTemplate.update(sql);
	}

	public int updateBySql(String sql, Object... args) {

		return jdbcTemplate.update(sql, args);
	}

	/**
	 * 更新表的几个字段
	 * 
	 * @param id
	 * @param columns
	 * @param values
	 * @return
	 */
	public int updateColumns(String id, String[] columns, Object... values) {
		if (columns.length != values.length) {
			try {
				throw new Exception("更新的列的数量和值的数量不相等");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		StringBuffer sql = new StringBuffer();
		sql.append(" UPDATE " + this.tableName + " SET ");
		for (int i = 0; i < columns.length; i++) {
			String column = columns[i];
			if (i == columns.length - 1) {
				sql.append(column).append(" = ? ");
			} else {
				sql.append(column).append(" = ? ,");
			}

		}
		sql.append(" WHERE " + this.IDName + " = '" + id + "'");

		return jdbcTemplate.update(sql.toString(), values);
	}
	
	
	/**
	 * 更新表的几个字段
	 * 
	 * @param id
	 * @param map
	 * @return
	 */
	public int updateByMap(String id, Map<String,Object> map) { 
		if (map == null || map.keySet().size() == 0) {
			try {
				throw new Exception("更新字段不能为空"); 
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		Set<String>  keys = map.keySet();
		int size = keys.size();
		Object[] values = new Object[size]; 
		int index = 0;
		
		StringBuffer sql = new StringBuffer();
		sql.append(" UPDATE " + this.tableName + " SET ");
		for (String key:keys) {
			if (index == size - 1) {
				sql.append(key).append(" = ? ");
			} else {
				sql.append(key).append(" = ? ,");
			}
			values[index] = map.get(key);
			index++;
		}
		sql.append(" WHERE " + this.IDName + " = '" + id + "'");

		return jdbcTemplate.update(sql.toString(), values);
	}
	
	
	public int[] batchUpdate(List<T> list) {

		if (list == null || list.size() == 0) {
			return null;
		}
		String sql = this.makeSql(SQL_UPDATE);
		List<Object[]> batchArgs = new ArrayList<Object[]>();
		for (T t : list) {
			Object[] args = this.setArgs(t, SQL_UPDATE);
			batchArgs.add(args);
		}
		return jdbcTemplate.batchUpdate(sql, batchArgs);
	}

	public int delete(T entity) {

		String sql = this.makeSql(SQL_DELETE);
		Object[] args = this.setArgs(entity, SQL_DELETE);
		int[] argTypes = this.setArgTypes(entity, SQL_DELETE);
		return jdbcTemplate.update(sql, args, argTypes);
	}

	public int deleteBySql(String sql) {

		return jdbcTemplate.update(sql);
	}

	/**
	 * 物理删除
	 * 
	 * @param sql
	 * @param args
	 */
	public int deleteBySql(String sql, Object... args) {

		return jdbcTemplate.update(sql, args);
	}

	/**
	 * 物理删除
	 * 
	 * @param id
	 */
	public int delete(Serializable id) {

		String sql = " DELETE FROM " + tableName + " WHERE " + IDName + " = ? ";
		return jdbcTemplate.update(sql, id);
	}

	/**
	 * 逻辑删除
	 * 
	 * @param id
	 */
	public int deleteLogic(Serializable id) {

		String sql = " UPDATE  " + tableName + " SET flagUse = 0  WHERE " + IDName + " = ? ";
		return jdbcTemplate.update(sql, id);
	}

	public void deleteAll() {

		String sql = " DELETE FROM " + tableName;
		jdbcTemplate.execute(sql);
	}

	public int[] batchDelete(List<T> list) {

		if (list == null || list.size() == 0) {
			return null;
		}
		String sql = this.makeSql(SQL_DELETE);
		int[] argTypes = this.setArgTypes(list.get(0), SQL_DELETE);
		List<Object[]> batchArgs = new ArrayList<Object[]>();
		for (T t : list) {
			Object[] args = this.setArgs(t, SQL_DELETE);
			batchArgs.add(args);
		}
		return jdbcTemplate.batchUpdate(sql, batchArgs, argTypes);
	}

	@SuppressWarnings("unchecked")
	public T queryById(Serializable id) {

		String sql = " SELECT * FROM " + tableName + "  WHERE " + IDName + " = ? ";
		RowMapper<?> rowMapper = BeanPropertyRowMapper.newInstance(entityClass);
		List<?> list = jdbcTemplate.query(sql, rowMapper, id);
		if (list != null && list.size() > 0) {
			return (T) list.get(0);
		} else {
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	public List<T> queryAll() {

		try {
			String sql = "SELECT * FROM " + tableName;
			RowMapper<?> rowMapper = BeanPropertyRowMapper.newInstance(entityClass);
			return (List<T>) jdbcTemplate.query(sql, rowMapper);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public int[] batchUpdate(String[] sqls) {

		return jdbcTemplate.batchUpdate(sqls);
	}

	public void execute(String sql) {

		jdbcTemplate.execute(sql);
	}
	public List<Map<String, Object>> queryForMapList(String sql) {

		return jdbcTemplate.queryForList(sql);
	}

	public List<Map<String, Object>> queryForMapList(String sql, Object... args) {

		return jdbcTemplate.queryForList(sql, args);
	}

	
	/**
	 * 返回当前实体的列表
	 * 
	 * @param sql
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<T> queryForList(String sql) {

		return (List<T>) jdbcTemplate.query(sql, RowMapperUtils.getRowMapper(entityClass));
	}

	/**
	 * 返回当前实体的列表
	 * 
	 * @param sql
	 * @param args
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<T> queryForList(String sql, Object... args) {

		try {
			return (List<T>) jdbcTemplate.query(sql, RowMapperUtils.getRowMapper(entityClass), args);
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * 获得某种实体的列表
	 * 
	 * @param sql
	 * @return
	 */
	public <A> List<A> queryForObjList(String sql, Class<A> clazz) {

		return (List<A>) jdbcTemplate.query(sql, RowMapperUtils.getRowMapper(clazz));
	}

	/**
	 * 获得某种实体的列表
	 * 
	 * @param sql
	 * @return
	 */
	public <A> A queryForObj(String sql, Class<A> clazz) {

		return (A) jdbcTemplate.queryForObject(sql, RowMapperUtils.getRowMapper(clazz));
	}

	public <A> A queryForObj(String sql, Class<A> clazz, Object... args) {

		return (A) jdbcTemplate.queryForObject(sql, RowMapperUtils.getRowMapper(clazz), args);
	}

	/**
	 * 获得某种实体的列表
	 * 
	 * @param sql
	 * @param args
	 * @return
	 */
	public <A> List<A> queryForObjList(String sql, Class<A> clazz, Object... args) {

		try {
			return (List<A>) jdbcTemplate.query(sql, RowMapperUtils.getRowMapper(clazz), args);
		} catch (Exception e) {
			return new ArrayList<A>();
		}

	}
	public String queryForString(String sql) {

		try {
			return jdbcTemplate.queryForObject(sql, String.class);
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}

	public String queryForString(String sql, Object... args) {

		try {
			return jdbcTemplate.queryForObject(sql, String.class, args);
		} catch (EmptyResultDataAccessException e) {
			return null;
		}

	}

	public Map<String, Object> queryForMap(String sql) {

		try {
			return jdbcTemplate.queryForMap(sql);
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}

	public Map<String, Object> queryForMap(String sql, Object... args) {

		try {
			return jdbcTemplate.queryForMap(sql, args);
		} catch (EmptyResultDataAccessException e) {
			return null;
		}

	}

	@SuppressWarnings("unchecked")
	public T queryForObject(String sql) {

		List<T> list = (List<T>) jdbcTemplate.query(sql, RowMapperUtils.getRowMapper(entityClass));
		if (list != null && list.size() > 0) {
			return list.get(0);
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public T queryForObject(String sql, Object... args) {

		try {
			List<T> list = (List<T>) jdbcTemplate.query(sql, RowMapperUtils.getRowMapper(entityClass), args);
			if (list != null && list.size() > 0) {
				return list.get(0);
			}
		} catch (Exception e) {
			return null;
		}
		return null;
	}

	/**
	 * 查找某些列
	 * @param id
	 * @param columns:eg(name,age,gender...) 
	 * @return
	 */
	public Map<String,Object> queryColumns(String id,String columns){
		String sql = "SELECT "+columns+" FROM " + tableName + "  WHERE " + IDName + " = ? ";
		try {
			return jdbcTemplate.queryForMap(sql,id);
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	/**
	 * 分页2.0
	 * 
	 * @param pager

	 * @return
	 */

	public QueryResult<T> findByPage(Pager pager) {

		try {
			return this.findByPage(pager.getPageNo(), pager.getPageSize(), pager.getConditions(), pager.getOrders(),
					pager.getExtendSQL());
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public QueryResult<T> findByPage(int pageNo, int pageSize, List<Condition> cnds, List<Order> orders,
			String extendSQL) {

		List<T> list = this.find(pageNo, pageSize, cnds, orders, extendSQL);
		int totalRow = this.count(cnds, extendSQL);
		QueryResult<T> Queryresult = new QueryResult<T>(list, totalRow, pageNo, pageSize);
		if (Queryresult.list.size() == 0 && pageNo > 1) {
			list = this.find(pageNo - 1, pageSize, cnds, orders, extendSQL);
			totalRow = this.count(cnds, extendSQL);
			Queryresult = new QueryResult<T>(list, totalRow, pageNo - 1, pageSize);
		}
		return Queryresult;
	}

	@SuppressWarnings("unchecked")
	public List<T> find(int pageNo, int pageSize, List<Condition> cnds, List<Order> orders, String extendSql) {

		StringBuffer sql = new StringBuffer();
		StringBuffer subSql = new StringBuffer();
		StringBuffer cndSql = new StringBuffer();
		StringBuffer orderByContent = new StringBuffer();
		List<Object> args = new ArrayList<Object>();

		sql.append("SELECT  *,1 as _xdfJdbcOrmRowNumber  FROM  ").append(tableName).append(" where 1=1 ");

		this.makeCndSql(cndSql, cnds, extendSql, args);

		if (StringUtils.isNotBlank(cndSql.toString())) {
			subSql.append(" AND ").append(cndSql.toString());
		}

		sql.append(subSql);
		
		if (orders != null && orders.size() > 0) {
			sql.append("ORDER BY ");
			for (Order order : orders) {
				String column = order.getColumn();
				String dir = order.getDir();
				orderByContent.append(column).append(" ").append(dir).append(",");
			}
			orderByContent = orderByContent.deleteCharAt(orderByContent.length() - 1);
		}/* else {
			orderByContent.append(" prjID ");
		}*/
		sql.append(orderByContent); 
		sql.append(" limit ?,?");
		args.add((pageNo - 1) * pageSize);
		args.add(pageSize);

		RowMapper<?> rowMapper = BeanPropertyRowMapper.newInstance(entityClass);
		return (List<T>) jdbcTemplate.query(sql.toString(), rowMapper, this.tran2argObjs(args));
	}

	@SuppressWarnings("deprecation")
	private int count(List<Condition> cnds, String extendSql) {

		List<Object> args = new ArrayList<Object>();
		StringBuffer cndSql = new StringBuffer();

		StringBuffer sql = new StringBuffer(" SELECT COUNT(*) FROM " + tableName +"  ");
		this.makeCndSql(cndSql, cnds, extendSql, args);

		if (StringUtils.isNotBlank(cndSql.toString())) {
			sql.append(" WHERE ").append(cndSql.toString());
		}

		return jdbcTemplate.queryForObject(sql.toString(), this.tran2argObjs(args),RowMapperUtils.getRowMapper(Integer.class));
	}

	/**
	 * 分頁3.0
	 * @param args
	 * @param args
	 * @return
	 */

	public QueryResult<T> findByPage(Pager pager, List<Object> args) {

		try {
			return this.findByPage(pager.getPageNo(), pager.getPageSize(), pager.getExtendSQL(), args,
					pager.getOrders());
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public QueryResult<T> findByPage(int pageNo, int pageSize, String extendSQL, List<Object> args,
									 List<Order> orders) {

		List<Object> orgArgs = new ArrayList<Object>();
		orgArgs.addAll(args);
		List<T> list = this.find(pageNo, pageSize, extendSQL, args, orders);
		int totalRow = this.count(extendSQL, orgArgs);
		QueryResult<T> Queryresult = new QueryResult<T>(list, totalRow, pageNo, pageSize);
		if (Queryresult.list.size() == 0 && pageNo > 1) {
			list = this.find(pageNo - 1, pageSize, extendSQL, args, orders);
			totalRow = this.count(extendSQL, orgArgs);
			Queryresult = new QueryResult<T>(list, totalRow, pageNo, pageSize);
		}
		return Queryresult;
	}

	@SuppressWarnings("unchecked")
	public List<T> find(int pageNo, int pageSize, String extendSQL, List<Object> args, List<Order> orders) {

		StringBuffer sql = new StringBuffer();
		StringBuffer subSql = new StringBuffer();
		StringBuffer orderByContent = new StringBuffer();
		sql.append("SELECT  *  FROM  ( ");

		if (orders != null && orders.size() > 0) {
			for (Order order : orders) {
				String column = order.getColumn();
				String dir = order.getDir();
				orderByContent.append(column).append(" ").append(dir).append(",");
			}
			orderByContent = orderByContent.deleteCharAt(orderByContent.length() - 1);
		} else {
			orderByContent.append(" CURRENT_TIMESTAMP ");
		}

		subSql.append(" SELECT  ROW_NUMBER() OVER (ORDER BY ").append(orderByContent)
				.append(" ) AS _xdfJdbcOrmRowNumber,* FROM ").append(tableName).append(" WHERE 1 = 1 ");

		subSql.append(" AND ").append(extendSQL);

		sql.append(subSql.toString()).append(
				" ) AS _xdfJdbcLimitUnit WHERE _xdfJdbcLimitUnit._xdfJdbcOrmRowNumber >=  ?  AND _xdfJdbcLimitUnit._xdfJdbcOrmRowNumber <=  ? ");
		args.add((pageNo - 1) * pageSize + 1);
		args.add(pageNo * pageSize);

		RowMapper<?> rowMapper = BeanPropertyRowMapper.newInstance(entityClass);
		return (List<T>) jdbcTemplate.query(sql.toString(), rowMapper, this.tran2argObjs(args));
	}

	@SuppressWarnings("deprecation")
	private int count(String extendSql, List<Object> args) {

		StringBuffer sql = new StringBuffer(" SELECT COUNT(*) FROM " + tableName);
		sql.append(" WHERE ").append(extendSql);
		return jdbcTemplate.queryForObject(sql.toString(),RowMapperUtils.getRowMapper(Integer.class), this.tran2argObjs(args));
	}

	private Object[] tran2argObjs(List<Object> args) {
		if (args == null || args.size() == 0) {
			return new Object[0];
		}
		Object[] argObjs = new Object[args.size()];
		for (int i = 0; i < args.size(); i++) {
			argObjs[i] = args.get(i);
		}
		return argObjs;
	}

	/**
	 * 生成条件SQL
	 */
	private void makeCndSql(StringBuffer cndSql, List<Condition> cnds, String extendSql, List<Object> args) {
		StringBuffer sql = new StringBuffer();

		if (cnds != null && cnds.size() > 0) {
			for (Condition cnd : cnds) {
				String column = cnd.getColumn();
				String[] value = cnd.getValue();
				String op = cnd.getOp();
				if (op.equals(Condition.EQ)) {
					if (StringUtils.isNotBlank(value[0].trim())) {
						sql.append(" " + column).append(" =  ? ").append(" AND ");
						args.add(value[0]);
					}
				} else if (op.equals(Condition.NE)) {
					sql.append(" " + column).append(" <>  ? ").append(" AND ");
					args.add(value[0]);
				} else if (op.equals(Condition.GT)) {
					sql.append(" " + column).append(" >  ? ").append(" AND ");
					args.add(value[0]);
				} else if (op.equals(Condition.LT)) {
					sql.append(" " + column).append(" <  ? ").append(" AND ");
					args.add(value[0]);
				} else if (op.equals(Condition.LE)) {
					sql.append(" " + column).append(" <=  ? ").append(" AND ");
					args.add(value[0]);
				} else if (op.equals(Condition.GE)) {
					sql.append(" " + column).append(" >=  ? ").append(" AND ");
					args.add(value[0]);
				} else if (op.equals(Condition.LIKE)) {
					if (StringUtils.isNotBlank(value[0].trim())) {
						sql.append(" " + column).append(" like  ? ").append(" AND ");
						args.add('%' + value[0] + '%');
					}
				} else if (op.equals(Condition.NOTLIKE)) {
					if (StringUtils.isNotBlank(value[0].trim())) {
						sql.append(" " + column).append(" not like  ? ").append(" AND ");
						args.add('%' + value[0] + '%');
					}
				} else if (op.equals(Condition.BWTEEN)) {
					sql.append(" " + column).append(" between  ? and ? ").append(" AND ");
					args.add(value[0]);
					args.add(value[1]);
				} else if (op.equals(Condition.IN)) {
					sql.append(" " + column).append(" in ( ");
					for (int i = 0; i < value.length; i++) {
						if (i != value.length - 1) {
							sql.append(" ? ").append(",");
						} else {
							sql.append(" ? ");
						}
						args.add(value[i]);
					}
					sql.append(" ) ").append(" AND ");
				} else if (op.equals(Condition.ISNULL)) {
					sql.append(" " + column).append(" is null ").append(" AND ");
				} else if (op.equals(Condition.ISNOTNULL)) {
					sql.append(" " + column).append(" is not null ").append(" AND ");
				}
			}
			int endIndex = sql.lastIndexOf(" AND ");
			if (endIndex > 0) {
				sql = new StringBuffer(sql.substring(0, endIndex));
			}
		} else {
			sql.append(" 1 = 1 ");
		}

		if (StringUtils.isNotBlank(extendSql)) {
			sql.append(" AND ").append(extendSql);
		}

		cndSql.append(sql);

	}

	// 组装SQL
	private String makeSql(String sqlFlag) {
		StringBuffer sql = new StringBuffer();
		Field[] fields = getDBFields(entityClass.getDeclaredFields());

		if (sqlFlag.equals(SQL_INSERT)) {
			sql.append(" INSERT INTO " + tableName);
			sql.append(" ( ");
			for (int i = 0; fields != null && i < fields.length; i++) {
				fields[i].setAccessible(true); // 暴力反射
				String columnName = fields[i].getName();
				Column column = fields[i].getAnnotation(Column.class);
				if (column != null && StringUtils.isNotBlank(column.name())) {
					columnName = column.name();
				}

				sql.append(columnName).append(",");
			}
			sql = sql.deleteCharAt(sql.length() - 1);
			sql.append(" ) VALUES ( ");
			for (int i = 0; fields != null && i < fields.length; i++) {
				sql.append("?,");
			}
			sql = sql.deleteCharAt(sql.length() - 1);
			sql.append(" ) ");
		} else if (sqlFlag.equals(SQL_UPDATE)) {
			sql.append(" UPDATE " + tableName + " SET ");
			for (int i = 0; fields != null && i < fields.length; i++) {
				fields[i].setAccessible(true); // 暴力反射
				if (fields[i].getAnnotation(Id.class) != null) {
					continue;
				}
				String columnName = fields[i].getName();
				Column column = fields[i].getAnnotation(Column.class);
				if (column != null && StringUtils.isNotBlank(column.name())) {
					columnName = column.name();
				}
				sql.append(columnName).append("=").append("?,");
			}
			sql = sql.deleteCharAt(sql.length() - 1);
			sql.append(" WHERE " + IDName + " = ? ");
		} else if (sqlFlag.equals(SQL_DELETE)) {
			sql.append(" DELETE FROM " + tableName + " WHERE " + IDName + " = ? ");
		}
		return sql.toString();

	}

	// 设置参数
	private Object[] setArgs(T entity, String sqlFlag) {
		Field[] fields = getDBFields(entityClass.getDeclaredFields());
		if (sqlFlag.equals(SQL_INSERT)) {
			Object[] args = new Object[fields.length];
			for (int i = 0; args != null && i < args.length; i++) {
				try {
					fields[i].setAccessible(true); // 暴力反射
					args[i] = fields[i].get(entity);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			return args;
		} else if (sqlFlag.equals(SQL_UPDATE)) {
			Object[] args = new Object[fields.length];
			Object IDArg = null;
			for (int i = 0; args != null && i < args.length; i++) {
				try {
					fields[i].setAccessible(true); // 暴力反射
					if (fields[i].getAnnotation(Id.class) != null) {
						IDArg = fields[i].get(entity);// 寻找主键
					} else {
						args[i] = fields[i].get(entity);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			for (int i = 0; i < args.length; i++) {
				if (i >= IDIndex && i < args.length - 1) {
					args[i] = args[i + 1];
				} else {
					args[i] = IDArg;
				}
			}
			return args;
		} else if (sqlFlag.equals(SQL_DELETE)) {
			Object[] args = new Object[1]; // 长度是1
			for (int i = 0; args != null && i < args.length; i++) {
				try {
					fields[i].setAccessible(true); // 暴力反射
					if (fields[i].getAnnotation(Id.class) != null) {
						args[0] = fields[i].get(entity);
						break;
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			return args;
		}
		return null;

	}

	// 设置参数类型（写的不全，只是一些常用的）
	private int[] setArgTypes(T entity, String sqlFlag) {
		Field[] fields = getDBFields(entityClass.getDeclaredFields());
		if (sqlFlag.equals(SQL_INSERT)) {
			int[] argTypes = new int[fields.length];
			try {
				for (int i = 0; argTypes != null && i < argTypes.length; i++) {
					fields[i].setAccessible(true); // 暴力反射
					argTypes[i] = getArgType(fields[i].get(entity));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return argTypes;
		} else if (sqlFlag.equals(SQL_UPDATE)) {
			int[] argTypes = new int[fields.length];
			int IDArgType = 0;
			try {
				for (int i = 0; argTypes != null && i < argTypes.length; i++) {
					fields[i].setAccessible(true); // 暴力反射
					if (fields[i].getAnnotation(Id.class) != null) {
						IDArgType = getArgType(fields[i].get(entity));
					} else {
						argTypes[i] = getArgType(fields[i].get(entity));
					}
				}

				for (int i = 0; i < argTypes.length; i++) {
					if (i >= IDIndex && i < argTypes.length - 1) {
						argTypes[i] = argTypes[i + 1];
					} else {
						argTypes[i] = IDArgType;
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return argTypes;

		} else if (sqlFlag.equals(SQL_DELETE)) {
			int[] argTypes = new int[1]; // 长度是1
			try {
				for (int i = 0; argTypes != null && i < argTypes.length; i++) {
					fields[i].setAccessible(true); // 暴力反射
					if (fields[i].getAnnotation(Id.class) != null) {
						argTypes[0] = getArgType(fields[i].get(entity));
						break;
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return argTypes;
		}
		return null;
	}

	private int getArgType(Object object) {
		if (object == null) {
			return Types.NULL;
		} else if (object.getClass().getName().equals("java.lang.String")) {
			return Types.VARCHAR;
		} else if (object.getClass().getName().equals("java.math.BigDecimal")) {
			return Types.DECIMAL;
		} else if (object.getClass().getName().equals("java.lang.Double")) {
			return Types.DECIMAL;
		} else if (object.getClass().getName().equals("java.lang.Float")) {
			return Types.FLOAT;
		} else if (object.getClass().getName().equals("java.lang.Integer")) {
			return Types.INTEGER;
		} else if (object.getClass().getName().equals("java.lang.Boolean")) {
			return Types.BOOLEAN;
		} else if (object.getClass().getName().equals("java.util.Date")) {
			return Types.TIMESTAMP;
		} else if (object.getClass().getName().equals("java.sql.Timestamp")) {
			return Types.TIMESTAMP;
		}

		return Types.NULL;
	}

	private Field[] getDBFields(Field[] fields) {
		List<Field> fieldList = new ArrayList<Field>();
		for (Field field : fields) {
			NotDBColumn column = field.getAnnotation(NotDBColumn.class);
			if (column == null) {
				fieldList.add(field);
			}
		}
		Field[] fs = (Field[]) fieldList.toArray(new Field[fieldList.size()]);
		return fs;
	}

	/**
	 * 获得flowId
	 * 
	 * @param
	 * @return flowId
	 */
	public Integer newFlowID() {

		return jdbcTemplate.execute(new ConnectionCallback<Integer>() {
			public Integer doInConnection(Connection con) throws SQLException, DataAccessException {
				String callSQL = "call PR_GetMaxFlowID(?,?)";
				CallableStatement callState = con.prepareCall(callSQL);
				callState.setString(1, tableName);
				callState.registerOutParameter(2, Types.INTEGER);
				boolean res = callState.execute();
				Integer resData = callState.getInt(2);
				return resData;
			}
		});
	}
}