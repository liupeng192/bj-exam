package cn.xdf.login.service.impl;

import cn.xdf.login.bean.LoginBean;
import cn.xdf.login.dao.LoginUserDao;
import cn.xdf.login.service.LoginUserServer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author liupeng
 * @date 2020/7/31-16:57
 **/
@Service
public class LoginUserServiceImpl implements LoginUserServer {
    @Autowired
    private LoginUserDao loginUserDao;

    public LoginBean findByUserName(String usrName)
    {
        return this.loginUserDao.getLoginUserByUserName(usrName);
    }

    public LoginBean findByUserTell(String tell)
    {
        return this.loginUserDao.getLoginUserByTell(tell);
    }

    public int addLoginUser(LoginBean loginBean)
    {
        return this.loginUserDao.save(loginBean);
    }
}
