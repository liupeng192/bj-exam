package cn.xdf.framework.assist;

public class Order {

	public static final String DESC = "desc";
	public static final String ASC = "asc";
	
	private String column;//排序的字段
	private String dir;//排序的方向
	
	
	public Order(String column,String dir){
		this.column = column;
		this.dir = dir;
	}
	
	public String getColumn() {
		return column;
	}
	public void setColumn(String column) {
		this.column = column;
	}
	public String getDir() {
		return dir;
	}
	public void setDir(String dir) {
		this.dir = dir;
	}
	
	public static Order asc(String column){
		return new Order(column,Order.ASC);
	}
	
	public static Order desc(String column){
		return new Order(column,Order.DESC);
	}
}
