package cn.xdf.utils;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;

import com.alibaba.fastjson.JSONObject;

public class Https {

	public static final String POST = "POST";
	public static final String GET = "GET";

	public static String doPost(String url, Map<String, String> params) {
		return doPost(url, params, null);
	}

	public static String doGet(String url, Map<String, String> paramMap) {
		return doGet(url, paramMap, null);
	}

	public static String doJsonPost(String url, JSONObject params) {
		return doJsonPost(url, params, null);
	}

	public static String doJsonPost(String url, String params) {
		return doJsonPost(url, params, null);
	}

	public static String doPost(String url, Map<String, String> params, Header[] headers) {
		HttpClient httpClient = new DefaultHttpClient();
		HttpPost request = new HttpPost(url);
		try {
			HttpParams httpParams = new BasicHttpParams();
			HttpConnectionParams.setConnectionTimeout(httpParams, 50000);
			HttpConnectionParams.setSoTimeout(httpParams, 50000);
			List<NameValuePair> nameValuePair = getPramsFromMap(params);

			if (headers != null && headers.length > 0) {
				request.setHeaders(headers);
			}

			request.setEntity(new UrlEncodedFormEntity(nameValuePair, "UTF-8"));
			request.setParams(httpParams);
			HttpResponse response = httpClient.execute(request);

			if (response.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = response.getEntity();
				String content = EntityUtils.toString(entity);// 取出应答字符串
				EntityUtils.consume(entity);
				return content;
			} else {
				request.abort();
			}
		} catch (Exception e) {
			request.abort();
			Log.error(e.getMessage(), e);
		} finally {
			if (request != null) {
				request.releaseConnection();
			}
			if (httpClient != null) {
				httpClient.getConnectionManager().shutdown();
			}
		}
		return null;
	}

	public static String doJsonPost(String url, JSONObject params, Header[] headers) {
		HttpClient httpClient = new DefaultHttpClient();
		HttpPost request = new HttpPost(url);
		try {
			HttpParams httpParams = new BasicHttpParams();
			HttpConnectionParams.setConnectionTimeout(httpParams, 50000);
			HttpConnectionParams.setSoTimeout(httpParams, 50000);

			if (headers != null && headers.length > 0) {
				request.setHeaders(headers);
			}

			StringEntity entity = new StringEntity(params.toJSONString(), "utf-8");// 解决中文乱码问题
			entity.setContentEncoding("UTF-8");
			entity.setContentType("application/json");

			request.setEntity(entity);
			request.setParams(httpParams);
			HttpResponse response = httpClient.execute(request);

			if (response.getStatusLine().getStatusCode() == 200) {
				String content = EntityUtils.toString(response.getEntity());// 取出应答字符串
				EntityUtils.consume(entity);
				return content;
			} else {
				request.abort();
			}
		} catch (Exception e) {
			request.abort();
			Log.error(e.getMessage(), e);
		} finally {
			if (request != null) {
				request.releaseConnection();
			}
			if (httpClient != null) {
				httpClient.getConnectionManager().shutdown();
			}
		}
		return null;
	}

	public static String doJsonPost(String url, String params, Header[] headers) {
		HttpClient httpClient = new DefaultHttpClient();
		HttpPost request = new HttpPost(url);
		try {
			HttpParams httpParams = new BasicHttpParams();
			HttpConnectionParams.setConnectionTimeout(httpParams, 50000);
			HttpConnectionParams.setSoTimeout(httpParams, 50000);

			if (headers != null && headers.length > 0) {
				request.setHeaders(headers);
			}

			StringEntity entity = new StringEntity(params, "utf-8");// 解决中文乱码问题
			entity.setContentEncoding("UTF-8");
			entity.setContentType("application/json");

			request.setEntity(entity);
			request.setParams(httpParams);
			HttpResponse response = httpClient.execute(request);

			if (response.getStatusLine().getStatusCode() == 200) {
				String content = EntityUtils.toString(response.getEntity());// 取出应答字符串
				EntityUtils.consume(entity);
				return content;
			} else {
				request.abort();
			}
		} catch (Exception e) {
			request.abort();
			Log.error(e.getMessage(), e);
		} finally {
			if (request != null) {
				request.releaseConnection();
			}
			if (httpClient != null) {
				httpClient.getConnectionManager().shutdown();
			}
		}
		return null;
	}

	public static String doXmlPost(String url, Map<String, String> xmlObj) {
		HttpClient httpClient = null;
		HttpPost httpPost = null;
		try {
			httpClient = new DefaultHttpClient();
			httpPost = new HttpPost(url);
			String postDataXML = AppUtils.tranDataXML(xmlObj);
			// 得指明使用UTF-8编码，否则到API服务器XML的中文不能被成功识别
			StringEntity postEntity = new StringEntity(postDataXML, "UTF-8");
			httpPost.addHeader("Content-Type", "text/xml");
			httpPost.setEntity(postEntity);
			HttpResponse response = httpClient.execute(httpPost);

			HttpEntity entity = response.getEntity();

			return EntityUtils.toString(entity, "UTF-8");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (httpPost != null) {
				httpPost.abort();
			}
		}
		return null;
	}

	public static String doGet(String url, Map<String, String> paramMap, Header[] headers) {
		String result = "";

		String paramString = getUrlParams(paramMap);
		paramString = paramString.replaceAll(" ", "%20");

		HttpClient httpClient = new DefaultHttpClient();
		// 拼接请求参数
		if(StringUtils.isNotBlank(paramString)){
			url = url + "?" + paramString;
		}
		Log.info(url);
		HttpGet request = new HttpGet(url);
		try {
			if (headers != null && headers.length > 0) {
				request.setHeaders(headers);
			}
			HttpParams httpParams = new BasicHttpParams();
			HttpConnectionParams.setConnectionTimeout(httpParams, 50000);
			HttpConnectionParams.setSoTimeout(httpParams, 50000);
			request.setParams(httpParams);
			HttpResponse response = httpClient.execute(request);

			if (response.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = response.getEntity();
				String content = EntityUtils.toString(entity);// 取出应答字符串
				EntityUtils.consume(entity);
				return content;
			} else {
				request.abort();
			}
		} catch (Exception e) {
			request.abort();
			e.printStackTrace();
			result = e.getMessage().toString();
		} finally {
			if (request != null) {
				request.releaseConnection();
			}
			if (httpClient != null) {
				httpClient.getConnectionManager().shutdown();
			}
		}

		return result;
	}
	
	/**
	 * 
	 * @Description: 测试GET方法
	 *  
	 * @Title: doGet    
	 * @param url
	 * @param paramMap
	 * @param headers
	 * @return	String
	 */
	public static String doMapHeaderGet(String url, Map<String, String> paramMap, Map<String, Object> headers) {
		String result = "";

		String paramString = getUrlParams(paramMap);
		paramString = paramString.replaceAll(" ", "%20");
		HttpClient httpClient = new DefaultHttpClient();
		// 拼接请求参数
		if(StringUtils.isNotBlank(paramString)){
			url = url + "?" + paramString;
		}
		Log.info(url);
		HttpGet request = new HttpGet(url);
		try {
			if (MapUtils.isNotEmpty(headers)) {
				Set<Entry<String, Object>> entrySet = headers.entrySet();
				Iterator<Entry<String, Object>> entryIterator = entrySet.iterator();
				while (entryIterator.hasNext()) {
					Entry<String, Object> entry = entryIterator.next();
					String key = entry.getKey();
					Object value = entry.getValue();
					request.setHeader(key, value.toString());
				}
			}
			HttpParams httpParams = new BasicHttpParams();
			HttpConnectionParams.setConnectionTimeout(httpParams, 50000);
			HttpConnectionParams.setSoTimeout(httpParams, 50000);
			request.setParams(httpParams);
			HttpResponse response = httpClient.execute(request);

			if (response.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = response.getEntity();
				String content = EntityUtils.toString(entity);// 取出应答字符串
				EntityUtils.consume(entity);
				return content;
			} else {
				request.abort();
			}
		} catch (Exception e) {
			request.abort();
			e.printStackTrace();
			result = e.getMessage().toString();
		} finally {
			if (request != null) {
				request.releaseConnection();
			}
			if (httpClient != null) {
				httpClient.getConnectionManager().shutdown();
			}
		}

		return result;
	}

	private static String getUrlParams(Map<String, String> paramMap) {
		String businessParamString = "";

		Set<Entry<String, String>> entrySet = paramMap.entrySet();
		Iterator<Entry<String, String>> entryIterator = entrySet.iterator();
		while (entryIterator.hasNext()) {
			Entry<String, String> entry = entryIterator.next();
			String paramKey = entry.getKey();
			String paramValue = entry.getValue();
			businessParamString += ("&" + paramKey + "=" + paramValue);
		}

		if(StringUtils.isNotBlank(businessParamString)){
			businessParamString = businessParamString.substring(1);
		}

		return businessParamString;
	}

	private static List<NameValuePair> getPramsFromMap(Map<String, String> params) {
		List<NameValuePair> result = new ArrayList<NameValuePair>();
		if (params != null && params.size() > 0) {
			for (String key : params.keySet()) {
				if (params.get(key) != null) {
					String value = params.get(key);
					result.add(new BasicNameValuePair(key, value));
				}
			}
		}
		return result;
	}
}