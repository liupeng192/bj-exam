package cn.xdf.rmi.data;

/**
 * @author liupeng
 * @date 2020/7/31-15:43
 **/
public class U2vmData {
    private String code;
    private String stat;
    private String targetUrl;
    private String clitId;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }

    public String getTargetUrl() {
        return targetUrl;
    }

    public void setTargetUrl(String targetUrl) {
        this.targetUrl = targetUrl;
    }

    public String getClitId() {
        return clitId;
    }

    public void setClitId(String clitId) {
        this.clitId = clitId;
    }
}
