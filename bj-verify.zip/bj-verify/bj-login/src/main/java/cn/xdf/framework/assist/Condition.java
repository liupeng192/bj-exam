package cn.xdf.framework.assist;

public class Condition {
	
	public static final String EQ = "=";
	public static final String NE = "<>";
	public static final String LIKE = "like";
	public static final String NOTLIKE = "not like";
	public static final String GT = ">";
	public static final String LT = "<";
	public static final String GE = ">=";
	public static final String LE = "<=";
	public static final String BWTEEN = "between";
	public static final String IN = "in";
	public static final String OR = "or";
	public static final String ISNULL = "is null";
	public static final String ISNOTNULL = "is not null";
	
	
	private String column;//列名
	private String op;//操作符
	private String[] value;//值
	
	public Condition(){}
	
	public Condition(String column,String op,String[] value){
		this.column = column;
		this.op = op;
		this.value = value;
	}
	
	public String getColumn() {
		return column;
	}
	public void setColumn(String column) {
		this.column = column;
	}
	public String getOp() {
		return op;
	}
	public void setOp(String op) {
		this.op = op;
	}
	public String[] getValue() {
		return value;
	}
	public void setValue(String[] value) {
		this.value = value;
	}
	
	public static Condition eq(String column,String[] value){
		return new Condition(column,Condition.EQ,value);
	}
	
	public static Condition ne(String column,String[] value){
		return new Condition(column,Condition.NE,value);
	}
	
	public static Condition like(String column,String[] value){
		return new Condition(column,Condition.LIKE,value);
	}
	
	public static Condition notlike(String column,String[] value){
		return new Condition(column,Condition.NOTLIKE,value);
	}
	
	public static Condition gt(String column,String[] value){
		return new Condition(column,Condition.GT,value);
	}
	
	public static Condition lt(String column,String[] value){
		return new Condition(column,Condition.LT,value);
	}
	
	public static Condition le(String column,String[] value){
		return new Condition(column,Condition.LE,value);
	}
	
	public static Condition ge(String column,String[] value){
		return new Condition(column,Condition.GE,value);
	}
	
	public static Condition between(String column,String[] value){
		return new Condition(column,Condition.BWTEEN,value);
	}
	
	public static Condition in(String column,String[] value){
		return new Condition(column,Condition.IN,value);
	}
	
	public static Condition isNull(String column){
		return new Condition(column,Condition.ISNULL,null);
	}
	
	public static Condition isNotNull(String column){
		return new Condition(column,Condition.ISNOTNULL,null);
	}
}
