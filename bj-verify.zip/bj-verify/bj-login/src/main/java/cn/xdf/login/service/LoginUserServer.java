package cn.xdf.login.service;

import cn.xdf.login.bean.LoginBean;

/**
 * @author liupeng
 * @date 2020/7/31-16:55
 **/
public interface LoginUserServer {

    public  LoginBean findByUserName(String paramString);

    public  LoginBean findByUserTell(String paramString);

    public abstract int addLoginUser(LoginBean paramLoginBean);
}
