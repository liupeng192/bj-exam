package cn.xdf.login.service;

import cn.xdf.login.bean.Credential;
import cn.xdf.login.bean.LoginUser;
import cn.xdf.rmi.data.U2AccessTokenDto;

import java.util.Set;

/**
 * @author liupeng
 * @date 2020/7/31-16:54
 **/

public  interface IAuthenticationHandler
{
    public  LoginUser authenticate(Credential paramCredential) throws Exception;

    public  Set<String> authedSystemIds(U2AccessTokenDto paramU2AccessTokenDto) throws Exception;

    public  U2AccessTokenDto autoLogin(String paramString);
}
