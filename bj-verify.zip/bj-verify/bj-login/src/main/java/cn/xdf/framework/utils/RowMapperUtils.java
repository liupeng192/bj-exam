package cn.xdf.framework.utils;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;


public class RowMapperUtils {
	@SuppressWarnings("unchecked")
	public static <N> RowMapper<N> getMapper(Class<N> clazz) {
        if (String.class.equals(clazz))
            return (RowMapper<N>) JdbcTemplateUtils.stringPRM;
        else if (Long.class.equals(clazz))
            return (RowMapper<N>) JdbcTemplateUtils.longPRM;
        else if (Date.class.equals(clazz))
            return (RowMapper<N>) JdbcTemplateUtils.datePRM;
        else if (Object.class.equals(clazz))
            return (RowMapper<N>) JdbcTemplateUtils.objPRM;
        else if (Integer.class.equals(clazz))
            return (RowMapper<N>) JdbcTemplateUtils.intPRM;
        else if (Double.class.equals(clazz))
            return (RowMapper<N>) JdbcTemplateUtils.doublePRM;
        else if (BigDecimal.class.equals(clazz))
            return (RowMapper<N>) JdbcTemplateUtils.bigdecimalPRM;
        else if (Map.class.equals(clazz))
            return (RowMapper<N>) JdbcTemplateUtils.mapPRM;
        else
            return BeanPropertyRowMapper.newInstance(clazz);
	}

    @SuppressWarnings("unchecked")
    public static  <A> RowMapper<A> getRowMapper(Class<A> clazz) {
        if (String.class.equals(clazz))
            return (RowMapper<A>) JdbcTemplateUtils.stringPRM;
        else if (Long.class.equals(clazz))
            return (RowMapper<A>) JdbcTemplateUtils.longPRM;
        else if (Date.class.equals(clazz))
            return (RowMapper<A>) JdbcTemplateUtils.datePRM;
        else if (Object.class.equals(clazz))
            return (RowMapper<A>) JdbcTemplateUtils.objPRM;
        else if (Integer.class.equals(clazz))
            return (RowMapper<A>) JdbcTemplateUtils.intPRM;
        else if (Double.class.equals(clazz))
            return (RowMapper<A>) JdbcTemplateUtils.doublePRM;
        else if (Map.class.equals(clazz))
            return (RowMapper<A>) JdbcTemplateUtils.mapPRM;
        else if(BigDecimal.class.equals(clazz))
        	return (RowMapper<A>) JdbcTemplateUtils.bigdecimalPRM;
        else
            return BeanPropertyRowMapper.newInstance(clazz);
    }
    
}
