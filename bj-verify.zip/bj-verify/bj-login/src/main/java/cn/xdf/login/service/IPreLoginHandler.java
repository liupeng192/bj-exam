package cn.xdf.login.service;

import javax.servlet.http.HttpSession;
import java.util.Map;

/**
 * @author liupeng
 * @date 2020/7/31-15:59
 **/
public interface IPreLoginHandler {
    public static final String SESSION_ATTR_NAME = "login_session_attr_name";

    public abstract Map<?, ?> handle(HttpSession paramHttpSession)
            throws Exception;
}
