package cn.xdf.login.controller;

import cn.xdf.config.ConfigMssage;
import cn.xdf.config.SubSystem;
import cn.xdf.framework.assist.ErrObject;
import cn.xdf.framework.assist.FerryInfo;
import cn.xdf.login.bean.Credential;
import cn.xdf.login.bean.LoginUser;
import cn.xdf.login.service.IAuthenticationHandler;
import cn.xdf.login.service.IPreLoginHandler;
import cn.xdf.login.service.impl.SimplIAuthenticationHandler;
import cn.xdf.login.service.impl.TellAuthenticationHandle;
import cn.xdf.rmi.data.U2AccessTokenDto;
import cn.xdf.rmi.data.U2Result;
import cn.xdf.rmi.data.U2vmData;
import cn.xdf.token.TokenManger;
import cn.xdf.utils.*;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import io.netty.util.internal.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author liupeng
 * @date 2020/7/31-15:35
 **/
@Controller
@RequestMapping("/login")
public class LoginController {
    @Autowired
    private ConfigMssage config;

    @RequestMapping("/view")
    public String toLogin(@RequestParam(required=false, defaultValue="") String redirect_uri, ModelMap modelMap, HttpServletResponse response, HttpServletRequest request)
            throws IOException
    {
        U2vmData vdata = new U2vmData();
        String client_id = request.getParameter("client_id");
        String state = request.getParameter("state");
        String code = request.getParameter("code");
        String response_type = request.getParameter("response_type");
        if (StringUtils.isEmpty(redirect_uri)) {
            redirect_uri = "http://bj.xdf.cn:9000/login";
        }
        vdata.setCode(code);
        vdata.setStat(state);
        vdata.setTargetUrl(redirect_uri);
        vdata.setClitId(client_id);
        request.getSession().setAttribute("target", vdata);
        if ((StringUtils.isEmpty(state)) || (TokenManger.validate(state) == null)) {
            return this.config.getLoginViewName();
        }
        return validateSuccess(redirect_uri, vdata, response);
    }

    @ResponseBody
    @RequestMapping("getVerificationCode")
    public FerryInfo getVerificationCode(HttpServletRequest req, @RequestBody JSONObject params, Model model)
    {
        FerryInfo info = new FerryInfo();
        try
        {
            String mobile = params.getString("mobile");
            String url = "http://wxconter.bj.xdf.cn/wechatserver/verificationCode/get";
            String modelid = this.config.getProperties("modelid");
            HashMap<String, String> param = new HashMap();
            param.put("telephone", mobile);
            param.put("modelId", modelid);

            String result = Https.doGet(url, param);
            JSONObject object = (JSONObject)JSON.parse(result);
            if (object.getString("result").equals("ok")) {
                RedisUtils.set("msgid_" + mobile, object.getString("msgId"));
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
            info.success = false;
            info.errObject = new ErrObject("获取验证码失败请重新获取");
        }
        return info;
    }

    @PostMapping
    public String doLogin(HttpServletRequest request, HttpSession session, HttpServletResponse response, ModelMap model)
    {
        final Map<String, String[]> params = request.getParameterMap();
        final Object sessionVal = session.getAttribute("target");
        U2AccessTokenDto u2AccessTokenDto = new U2AccessTokenDto();
        Credential credential = new Credential()
        {
            public String getParameter(String name)
            {
                String[] tmp = (String[])params.get(name);
                return (tmp != null) && (tmp.length > 0) ? tmp[0] : null;
            }

            public String[] getParameterValue(String name)
            {
                return (String[])params.get(name);
            }

            public Object getSettedSessionValue()
            {
                return sessionVal;
            }
        };
        IAuthenticationHandler iauthenticationHandler = null;
        String isTell = request.getParameter("isTell");
        if ("0".equals(isTell)) {
            iauthenticationHandler = (IAuthenticationHandler) SpringUtils.getInstance(TellAuthenticationHandle.class);
        } else if ("1".equals(isTell)) {
            iauthenticationHandler = (IAuthenticationHandler)SpringUtils.getInstance(SimplIAuthenticationHandler.class);
        }
        try
        {
            LoginUser loginUserdb = iauthenticationHandler.authenticate(credential);
            if (loginUserdb.getStatus() == 0)
            {
                model.put("errorMsg", loginUserdb.getMessage());
                return this.config.getLoginViewName();
            }
            U2vmData u2vmData = loginUserdb.getU2vmData();
            u2AccessTokenDto.setUserId(loginUserdb.getUserId());
            u2AccessTokenDto.setEmail(loginUserdb.getUserName());
            u2AccessTokenDto.setMobile(loginUserdb.getMobile());
            authSuccess(response, u2AccessTokenDto, u2vmData);
            String backUrl = u2vmData.getTargetUrl();
            session.setAttribute("current_user", loginUserdb);
            return validateSuccess(backUrl, u2vmData, response);
        }
        catch (Exception ex)
        {
            ex.printStackTrace();

            model.put("errorMsg", "系统错误");
        }
        return this.config.getLoginViewName();
    }

    @RequestMapping("/perLogin")
    @ResponseBody
    public Object perLogin(HttpSession session)
            throws Exception
    {
        IPreLoginHandler preLoginHandler = this.config.getPreLoginHandler();
        if (preLoginHandler == null) {
            throw new Exception("没有配置IPreLoginHandler的实例 无法进行预处理");
        }
        return preLoginHandler.handle(session);
    }

    @RequestMapping("/logOut")
    public String logOut(@RequestParam(required=false) String backUrl, HttpServletRequest request, HttpServletResponse response)
            throws IOException
    {
        String token = CookieUtil.getCookie("TOKEN", request);
        TokenManger.invlid(token);
        Cookie cookie = new Cookie("u2state", "token is time out");
        cookie.setMaxAge(0);
        response.addCookie(cookie);

        List<SubSystem> lists = this.config.getSubSystems();
        for (SubSystem subSystem : lists) {
            subSystem.noticeLoginOut(token);
        }
        if (backUrl == null) {
            return "loginOut";
        }
        response.sendRedirect(backUrl);
        return null;
    }

    private String validateSuccess(String backUrl, U2vmData u2vmData, HttpServletResponse response)
            throws IOException
    {
        if (backUrl != null)
        {
            String targetUrl = StringUtils.appendUrlParameter(URLDecoder.decode(backUrl), "state", u2vmData.getStat() !=null?u2vmData.getStat():"");
            response.sendRedirect(targetUrl);
            return null;
        }
        return "index";
    }

    private void authSuccess(HttpServletResponse response, U2AccessTokenDto u2AccessTokenDto, U2vmData u2vmData)
            throws Exception
    {
        String u2statevalue = "";
        if ((u2vmData == null) || (StringUtils.isEmpty(u2vmData.getStat()))) {
            u2statevalue = System.currentTimeMillis() + "XDF";
        } else {
            u2statevalue = u2vmData.getStat();
        }
        U2AccessTokenDto testU2AccessToken = TokenManger.validate(u2statevalue);
        if (testU2AccessToken == null)
        {
            TokenManger.addToken(u2statevalue, u2AccessTokenDto);

            Cookie cookie = new Cookie("U2Token", u2statevalue);
            cookie.setDomain("xdf.cn");
            response.addCookie(cookie);
        }
    }

    @PostMapping("/GetAccessToken")
    @ResponseBody
    public String GetAccessToken(HttpServletRequest request)
    {
        U2Result u2Result = new U2Result();
        String state = request.getParameter("state");
        String code = request.getParameter("code");
        String redirect_uri = request.getParameter("redirect_uri");
        String client_secret = request.getParameter("client_secret");
        String client_id = request.getParameter("client_id");
        String grant_type = request.getParameter("authorization_code");
        if (!"".equals(state))
        {
            U2AccessTokenDto u2AccessTokenDto = TokenManger.validate(state);
            if (u2AccessTokenDto == null)
            {
                u2Result.Status = 0;
                u2Result.Message = "用户验证失败";
                String str = JSONObject.toJSONString(u2Result);
                return str;
            }
            u2Result.Status = 1;
            u2Result.Data = u2AccessTokenDto;
            u2Result.Message = "用户验证成功";
            String str = JSONObject.toJSONString(u2Result);
            return str;
        }
        u2Result.Status = 0;
        u2Result.Message = "参数错误";
        String str = JSONObject.toJSONString(u2Result);
        return str;
    }

    public String validateSuccess(String backUrl, String token, LoginUser loginUser, HttpServletResponse response, ModelMap modelMap)
            throws Exception
    {
        if (backUrl != null)
        {
            response.sendRedirect(StringUtils.appendUrlParameter(backUrl, "u2state", token));
            return null;
        }
        modelMap.put("sysList", this.config.getSubSystems());
        modelMap.put("loginUser", loginUser);
        return this.config.getLoginViewName();
    }
}
