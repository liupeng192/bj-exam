package cn.xdf.framework.assist;

public class ErrObject {
	// 错误编码
	public String errCode = "";
	
    //错误信息
	public String errMess = "";

	//错误详情
	public String errDetail = "";
	

	public ErrObject(){
		
	}

	public ErrObject(String AerrMess){
		this.errMess = AerrMess;
		this.errCode = "ERROR";
		this.errDetail = "未设置错误编码和详情";
	}
	
	public ErrObject(String AerrCode, String AerrMess){
		this.errCode = AerrCode;
		this.errMess = AerrMess;		
		this.errDetail = "";
	}	
	
	public ErrObject(String AerrCode, String AerrMess, String AerrDetail){
		this.errMess = AerrMess;
		this.errCode = AerrCode;
		this.errDetail = AerrDetail;
	}

	public String getErrCode() {
		return errCode;
	}

	public void setErrCode(String errCode) {
		this.errCode = errCode;
	}

	public String getErrMess() {
		return errMess;
	}

	public void setErrMess(String errMess) {
		this.errMess = errMess;
	}

	public String getErrDetail() {
		return errDetail;
	}

	public void setErrDetail(String errDetail) {
		this.errDetail = errDetail;
	}
}