package cn.xdf.framework.utils;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.Map;

import org.springframework.jdbc.core.ColumnMapRowMapper;
import org.springframework.jdbc.core.RowMapper;

public interface  JdbcTemplateUtils {
 
	/**
	 * map类型时所得结果集处理 
	 */
	public static RowMapper<Map<String,Object>> mapPRM = new ColumnMapRowMapper();
    
	
	public static RowMapper<Date> datePRM = new RowMapper<Date>() {
		public Date mapRow(ResultSet rs, int rownum) throws SQLException {
			return rs.getTime(1);
		}
	};
	public static RowMapper<Long> longPRM = new RowMapper<Long>() {
		public Long mapRow(ResultSet rs, int rownum) throws SQLException {
			return rs.getLong(1);
		}
	};
	public static RowMapper<Double> doublePRM = new RowMapper<Double>() {
		public Double mapRow(ResultSet rs, int rownum) throws SQLException {
			return rs.getDouble(1);
		}
	};
	public static RowMapper<Integer> intPRM = new RowMapper<Integer>() {
		public Integer mapRow(ResultSet rs, int rownum) throws SQLException {
			return rs.getInt(1);
		}
	};
	public static RowMapper<Object> objPRM = new RowMapper<Object>() {
		public Object mapRow(ResultSet rs, int rownum) throws SQLException {
			return rs.getObject(1);
		}
	};
	public static RowMapper<String> stringPRM = new RowMapper<String>() {
		public String mapRow(ResultSet rs, int rownum) throws SQLException {
			return rs.getString(1);
		}
	};
	public static RowMapper<BigDecimal> bigdecimalPRM = new RowMapper<BigDecimal>() {
		public BigDecimal mapRow(ResultSet rs, int rownum) throws SQLException {
			return rs.getBigDecimal(1);
		}
	};
}
