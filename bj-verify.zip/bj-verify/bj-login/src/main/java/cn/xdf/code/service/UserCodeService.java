package cn.xdf.code.service;

import cn.xdf.code.bean.ConfirmCode;
import cn.xdf.code.bean.UserCode;

import java.util.List;

/**
 * @author liupeng
 * @date 2020/7/31-17:36
 **/
public interface UserCodeService {
    public  void addUserCode(UserCode paramUserCode);

    public  void addConfimCode(ConfirmCode paramConfirmCode);

    public  List<UserCode> queryUserCodes(UserCode paramUserCode);
}
