package cn.xdf.framework.annotation;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * 视图
 * @author luanhaibin
 *
 */
@Target(TYPE)
@Retention(RUNTIME)
public @interface View {
	String name() default "";
}
