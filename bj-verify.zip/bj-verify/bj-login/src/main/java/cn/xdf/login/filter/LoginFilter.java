package cn.xdf.login.filter;

import cn.xdf.utils.StringUtils;
import io.netty.util.internal.StringUtil;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author liupeng
 * @date 2020/7/31-15:25
 **/
public class LoginFilter implements Filter {
    protected static List<String> staticStr = new ArrayList();
    protected static List<Pattern> notLoginPatterns = new ArrayList();

    static
    {
        notLoginPatterns.add(Pattern.compile("/login"));
        notLoginPatterns.add(Pattern.compile("/login/view"));
        notLoginPatterns.add(Pattern.compile("/login/getVerificationCode"));
        notLoginPatterns.add(Pattern.compile("/code/confirmCode"));
        notLoginPatterns.add(Pattern.compile("/code/querySutCode"));
        notLoginPatterns.add(Pattern.compile("/login/GetAccessToken"));

        staticStr.add(".css");
        staticStr.add(".js");
        staticStr.add(".jpg");
        staticStr.add(".png");
    }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException
    {
        HttpServletRequest httpRequest = (HttpServletRequest)request;
        HttpServletResponse httpResponse = (HttpServletResponse)response;
        String url = httpRequest.getRequestURI().substring(httpRequest.getContextPath().length());
        if ((isNotLoginInclude(url)) || (isStatic(url)))
        {
            chain.doFilter(httpRequest, httpResponse);
            return;
        }
        httpResponse.sendRedirect("/login/view");
    }

    private boolean isNotLoginInclude(String url)
    {
        for (Pattern pattern : notLoginPatterns)
        {
            Matcher matcher = pattern.matcher(url);
            if (matcher.matches()) {
                return true;
            }
        }
        return false;
    }

    private boolean isStatic(String url)
    {
        for (String str : staticStr) {
            if ((StringUtils.isNotEmpty(url)) && (url.lastIndexOf(".") > 0) &&
                    (str.equals(url.substring(url.lastIndexOf("."), url.length())))) {
                return true;
            }
        }
        return false;
    }

    public void init(FilterConfig filterConfig)
            throws ServletException
    {}

    public void destroy() {}
}
