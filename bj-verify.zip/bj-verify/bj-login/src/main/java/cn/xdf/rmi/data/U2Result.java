package cn.xdf.rmi.data;

/**
 * @author liupeng
 * @date 2020/7/31-16:08
 **/
public class U2Result {
    public int Status = 0;
    public Object Data;
    public String Message;
}
