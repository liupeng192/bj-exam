package cn.xdf.framework.annotation;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * 表
 * @author luanhaibin
 *
 */
@Target(TYPE)
@Retention(RUNTIME)
public @interface Table {
	String name() default "";
}