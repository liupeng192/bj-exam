package cn.xdf.code.controller;

import cn.xdf.code.bean.ConfirmCode;
import cn.xdf.code.bean.UserCode;
import cn.xdf.code.service.UserCodeService;
import cn.xdf.login.bean.LoginUser;
import cn.xdf.rmi.data.U2AccessTokenDto;
import cn.xdf.rmi.data.U2Result;
import cn.xdf.rmi.data.U2vmData;
import cn.xdf.token.TokenManger;
import cn.xdf.utils.DES;
import cn.xdf.utils.RedisUtils;
import cn.xdf.utils.RestRemoteUtils;
import cn.xdf.utils.StringUtils;
import com.alibaba.fastjson.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * @author liupeng
 * @date 2020/7/31-17:47
 **/
@Controller
@RequestMapping("/code")
public class CodeController {
    @Autowired
    private UserCodeService userCodeService;

    @RequestMapping(value = "/querySutCode")
    public String querySutCode(HttpServletRequest request, ModelMap model, HttpServletResponse response) throws Exception{
        LoginUser loginUser = new LoginUser();
        String userName = request.getParameter("userName");
        String state = request.getParameter("state");
        String backUrl = request.getParameter("backUrl");
        U2AccessTokenDto u2AccessTokenDto =  TokenManger.validate(state);
        if(StringUtils.isEmpty(state) || u2AccessTokenDto ==null){
            //response.sendRedirect(StringUtil.appendUrlParameter("http://bjpassport.xdf.cn:9000/code/failSutCode", "u2state", "token"));
            // response.sendRedirect("/code/failSutCode");
            return "redirect:/code/failSutCode";
        }
        UserCode userCode = new UserCode();
        userCode.setUserName(userName);
        try {
            String userid= RestRemoteUtils.queryU2UserIdByTellV5(userName);
            if(StringUtils.isEmpty(userid)){
                userid=RestRemoteUtils.queryU2UserIdByEmailV5(userName);
            }
            if(StringUtils.isNotEmpty(userid)){
                loginUser.setUserId(userid);
                List<String> querySutcodes = RestRemoteUtils.queryStudentCode(userid,null);
                List<UserCode> dbuserCodes = userCodeService.queryUserCodes(userCode);
                if(querySutcodes!=null && querySutcodes.size()>0){
                    for(String stucode : querySutcodes) {
                        if(dbuserCodes !=null && dbuserCodes.size()>0){
                            List<UserCode> filterList = dbuserCodes.stream().filter(user -> user.getUserCode().equals(stucode)).collect(Collectors.toList());
                            if(filterList !=null && filterList.size()>0){
                                break;
                            }
                        }
                        String codeuuid = UUID.randomUUID().toString();
                        userCode.setId(codeuuid);
                        U2vmData u2vmData = RedisUtils.get("target",U2vmData.class);
                        if(u2vmData !=null){
                            userCode.setStateCode(u2vmData.getCode());
                        }
                        userCode.setUserName(userName);
                        userCode.setStuid(userName);
                        userCode.setUserId(userid);
                        userCode.setUserCode(stucode);
                        userCode.setCreateTime(new Date());
                        userCodeService.addUserCode(userCode);
                    }
                }
            }

        } catch (Exception exception) {
            exception.printStackTrace();
        }
        UserCode queryCode = new UserCode();
        queryCode.setUserName(userCode.getUserName());
        List<UserCode> userCodes = userCodeService.queryUserCodes(queryCode);
        List<String> codes=userCodes.stream().map(code -> code.getUserCode()).collect(Collectors.toList());
        loginUser.setUserCodes(codes);

        U2vmData u2vmData = new U2vmData();
        u2vmData.setTargetUrl(DES.encrypt(backUrl));
        loginUser.setU2vmData(u2vmData);
        loginUser.setUserName(userName);
        loginUser.setStatCode(state);
        model.put("loginUser",loginUser);

        return"course" ;
    }
    @RequestMapping("/failSutCode")
    @ResponseBody
    public String failSutCode(){
        U2Result u2Result = new U2Result();
        u2Result.Status=0;
        u2Result.Message="用户未登录或验证失败";
        String str = JSONObject.toJSONString(u2Result);
        return str;
    }
    @RequestMapping("/confirmCode")
    public String confirmCode(HttpServletRequest request, HttpServletResponse response){
        ConfirmCode confirmCode = new ConfirmCode();
        U2Result u2Result = new U2Result();
        String userName=request.getParameter("userName");
        String userId=request.getParameter("userId");
        String stucode=request.getParameter("stucode");
        String state=request.getParameter("state");
        String uuid = UUID.randomUUID().toString();
        confirmCode.setConfirID(uuid);
        confirmCode.setUserId(userId);
        confirmCode.setUserName(userName);
        confirmCode.setStuCode(stucode);
        confirmCode.setConfirmTime(new Date());
        userCodeService.addConfimCode(confirmCode);
        U2AccessTokenDto u2AccessTokenDto = TokenManger.validate(state);
        u2AccessTokenDto.setStuCode(stucode);
        u2AccessTokenDto.setMobile(userName);
        u2AccessTokenDto.setUserName(userName);
        u2AccessTokenDto.setUserId(userId);
        u2Result.Data=u2AccessTokenDto;
        u2Result.Status=1;
        u2Result.Message="获取数据成功";
        String str = JSONObject.toJSONString(u2Result);
        return "redirect:/code/failSutCode";

    }

}
