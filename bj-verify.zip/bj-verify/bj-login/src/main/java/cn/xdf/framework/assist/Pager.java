package cn.xdf.framework.assist;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;

public class Pager {

	private Integer pageNo = 1;
	private Integer pageSize = 20;
	private List<Condition> conditions = new ArrayList<Condition>();
	private List<Order> orders = new ArrayList<Order>();
	private String extendSQL;
	
	public Integer getPageNo() {
		return pageNo;
	}
	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}
	public Integer getPageSize() {
		return pageSize;
	}
	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
	public List<Condition> getConditions() {
		return conditions;
	}
	public void setConditions(List<Condition> conditions) {
		this.conditions = conditions;
	}
	public List<Order> getOrders() {
		return orders;
	}
	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}
	public String getExtendSQL() {
		return extendSQL;
	}
	public void setExtendSQL(String extendSQL) {
		this.extendSQL = extendSQL;
	}
	/**
	 * 添加查询字段
	 * 
	 * @param cnd
	 * @return Pager
	 */
	public Pager addCondition(Condition cnd){
		if(this.conditions==null){
			this.conditions = new ArrayList<Condition>();
		}
		this.conditions.add(cnd);
		return this;
	}
	/**
	 * 添加排序字段
	 * 
	 * @param order
	 * @return Pager
	 */
	public Pager addOrder(Order order){
		if(this.orders==null){
			this.orders = new ArrayList<Order>();
		}
		this.orders.add(order);
		return this;
	}
	
	
	/**
	 * 从Pager中获取查询条件信息
	 * 
	 * @param pager
	 *            分页查询信息
	 * @param column
	 *            列名
	 * @return Condition
	 */
	public Condition getCondition(Pager pager, String column) {
		List<Condition> list = pager.getConditions();
		Condition condition = new Condition();
		if(CollectionUtils.isEmpty(list)){
			return condition;
		}
		for(Condition c : list){
			if(c.getColumn().equals(column)){
				condition = c;
				break;
			}
		}
		
		return condition;
	}
	
	/**
	 * 从Pager中移除查询条件信息
	 * 
	 * @param pager
	 *            分页查询信息
	 * @param column
	 *            列名
	 * @return boolean
	 */
	public boolean removeCondition(Pager pager, String column){
		try {
			List<Condition> list = pager.getConditions();
			if(CollectionUtils.isEmpty(list)){
				return true;
			}
			for(Condition condition : list){
				if(condition.getColumn().equals(column)){
					list.remove(condition);
					break;
				}
			}
			pager.setConditions(list);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}
	
	/**
	 * 从Pager中移除排序条件信息
	 * 
	 * @param pager
	 *            分页查询信息
	 * @param column
	 *            列名
	 * @return boolean
	 */
	public boolean removeOrder(Pager pager, String column){
		try {
			List<Order> list = pager.getOrders();
			if(CollectionUtils.isEmpty(list)){
				return true;
			}
			for(Order order : list){
				if(order.getColumn().equals(column)){
					list.remove(order);
					break;
				}
			}
			pager.setOrders(list);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}
}
