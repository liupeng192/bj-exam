package cn.xdf.config;

import com.alibaba.fastjson.support.spring.FastJsonRedisSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.core.annotation.Order;
import org.springframework.data.redis.connection.RedisSentinelConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import redis.clients.jedis.JedisPoolConfig;

import java.util.HashSet;
import java.util.Set;

/**
 * @author liupeng
 * @date 2020/7/31-16:02
 **/
public class RedisConfig {
    @Value("${redis.maxIdle}")
    private Integer maxIdle;
    @Value("${redis.maxTotal}")
    private Integer maxTotal;
    @Value("${redis.maxWaitMillis}")
    private Integer maxWaitMillis;
    @Value("${redis.testOnBorrow}")
    private boolean testOnBorrow;
    @Value("${redis.database}")
    private int database;
    @Value("${redis.hostName}")
    private String hostName;
    @Value("${redis.port}")
    private Integer port;
    @Value("${redis.password}")
    private String password;
    @Value("${spring.redis.sentinel.master}")
    private String master;
    @Value("${spring.redis.sentinel.nodes}")
    private String redisNodes;

    public JedisPoolConfig redisPoolFactory()
            throws Exception
    {
        JedisPoolConfig pool = new JedisPoolConfig();
        pool.setMaxIdle(this.maxIdle.intValue());
        pool.setMaxTotal(this.maxTotal.intValue());
        pool.setMaxWaitMillis(this.maxWaitMillis.intValue());
        pool.setTestOnBorrow(this.testOnBorrow);
        return pool;
    }

    @Bean({"redisTemplate"})
    @Order(2)
    public RedisTemplate<Object, Object> redisTemplate(JedisConnectionFactory jedisConnectionFactory)
    {
        RedisTemplate<Object, Object> redisTemplate = new RedisTemplate();
        redisTemplate.setConnectionFactory(jedisConnectionFactory);
        redisTemplate.setKeySerializer(new StringRedisSerializer());
        redisTemplate.setValueSerializer(new FastJsonRedisSerializer(Object.class));

        redisTemplate.setHashKeySerializer(new StringRedisSerializer());
        redisTemplate.setHashValueSerializer(new FastJsonRedisSerializer(Object.class));
        return redisTemplate;
    }

    public RedisSentinelConfiguration redisSentinelConfiguration()
    {
        Set<String> setRedisNode = new HashSet();
        String[] host = this.redisNodes.split(",");
        for (String redisHost : host) {
            setRedisNode.add(redisHost);
        }
        RedisSentinelConfiguration configuration = new RedisSentinelConfiguration(this.master, setRedisNode);
        configuration.setPassword(this.password);
        configuration.setDatabase(this.database);
        return configuration;
    }

    @Bean
    @Order(1)
    public JedisConnectionFactory jedisConnectionFactory()
    {
        JedisConnectionFactory jedisconnet = null;
        try
        {
            jedisconnet = new JedisConnectionFactory(redisSentinelConfiguration(), redisPoolFactory());
        }
        catch (Exception exception)
        {
            exception.printStackTrace();
        }
        return jedisconnet;
    }
}
