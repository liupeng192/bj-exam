package cn.xdf.login.service.impl;


import cn.xdf.config.ConfigMssage;
import cn.xdf.login.bean.Credential;
import cn.xdf.login.bean.LoginBean;
import cn.xdf.login.bean.LoginUser;
import cn.xdf.login.service.IAuthenticationHandler;
import cn.xdf.login.service.LoginUserServer;
import cn.xdf.rmi.data.U2AccessTokenDto;
import cn.xdf.rmi.data.U2vmData;
import cn.xdf.user.bean.UserInfo;
import cn.xdf.user.service.UserService;
import cn.xdf.utils.Https;
import cn.xdf.utils.RedisUtils;
import cn.xdf.utils.RestRemoteUtils;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import java.util.Date;
import java.util.HashMap;
import java.util.Set;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author liupeng
 * @date 2020/7/31-17:02
 **/
@Service
public class TellAuthenticationHandle implements IAuthenticationHandler
{
    @Autowired
    private ConfigMssage appConfig;
    @Autowired
    private LoginUserServer loginUserServer;
    @Autowired
    private UserService userService;
    @Override
    public LoginUser authenticate(Credential credential) throws Exception
    {
        String verifycode = credential.getParameter("tellCode");
        String phone = credential.getParameter("tell");
        String code = (String) RedisUtils.get("msgid_" + phone, String.class);
        LoginUser loginUser = new LoginUser();
        if (code != null)
        {
            String url = "http://wxconter.bj.xdf.cn/wechatserver/verificationCode/validate";
            HashMap<String, String> param = new HashMap();
            param.put("msgId", code);
            param.put("telephone", phone);
            param.put("verificationCode", verifycode);
            String ret = Https.doGet(url, param);
            U2vmData u2vmData = (U2vmData)credential.getSettedSessionValue();
            JSONObject object = (JSONObject) JSON.parse(ret);
            String loginUuid = UUID.randomUUID().toString();
            String userUuid = UUID.randomUUID().toString();
            if ("error".equals(object.getString("result")))
            {
                loginUser.setStatus(0);
                loginUser.setMessage(object.getString("errorMsg"));
            }
            else
            {
                UserInfo userInfo = new UserInfo();
                LoginBean loginBean = new LoginBean();
                String userId = RestRemoteUtils.queryU2UserIdByTellV5(phone);
                userInfo.setUserName(phone);
                UserInfo currInfo = this.userService.getUserInfo(userInfo);
                if (currInfo == null)
                {
                    userInfo.setId(userUuid);
                    userInfo.setUserID(userId);
                    userInfo.setMobile(phone);
                    userInfo.setCreateTime(new Date());
                    userInfo.setFlagModify(1);
                    this.userService.addUserInfo(userInfo);
                    loginBean.setUserLoginId(userUuid);
                }
                else
                {
                    loginBean.setUserLoginId(currInfo.getId());
                    loginBean.setCreateTime(currInfo.getCreateTime());
                }
                loginBean.setId(loginUuid);
                loginBean.setUserName(phone);
                loginBean.setUserId(userId);
                loginBean.setLastLoginTime(new Date());
                this.loginUserServer.addLoginUser(loginBean);
                loginUser.setStatus(1);
                loginUser.setU2vmData(u2vmData);
                loginUser.setMobile(phone);
                loginUser.setUserName(phone);
                return loginUser;
            }
        }
        return loginUser;
    }



    @Override
    public Set<String> authedSystemIds(U2AccessTokenDto loginUser)
            throws Exception
    {
        return null;
    }
    @Override
    public U2AccessTokenDto autoLogin(String lt)
    {
        return null;
    }
}

