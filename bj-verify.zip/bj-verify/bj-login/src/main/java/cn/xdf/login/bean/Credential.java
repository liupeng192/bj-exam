package cn.xdf.login.bean;

/**
 * @author liupeng
 * @date 2020/7/31-16:53
 **/
public abstract class Credential {
    private String error;

    public abstract String getParameter(String paramString);

    public abstract String[] getParameterValue(String paramString);

    public abstract Object getSettedSessionValue();

    public String getError()
    {
        return this.error;
    }

    public void setError(String error)
    {
        this.error = error;
    }
}
