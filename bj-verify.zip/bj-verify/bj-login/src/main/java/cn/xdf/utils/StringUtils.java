package cn.xdf.utils;

/**
 * @author liupeng
 * @date 2020/7/31-16:13
 **/
import java.net.URLEncoder;

import java.io.UnsupportedEncodingException;
import java.util.Map;
import java.util.Set;

public class StringUtils extends org.apache.commons.lang3.StringUtils {
    public static boolean isEmpty(String target)
    {
        boolean isEmpty = false;
        if ((target == null) || ("".equals(target)) || ("null".equals(target))) {
            isEmpty = true;
        }
        return isEmpty;
    }

    public static String appendUrlParameter(String origUrl, String parameterName, String parameterVal)
    {
        if (origUrl == null) {
            return null;
        }
        String bound = origUrl.contains("?") ? "&" : "?";
        try
        {
            return origUrl + bound + parameterName + "=" + URLEncoder.encode(parameterVal, "UTF-8");
        }
        catch (UnsupportedEncodingException e) {}
        return null;
    }

    private static String BuildPostData(Map<String, String> parameters)
    {
        StringBuilder postData = new StringBuilder();
        boolean hasParam = false;

        Set<Map.Entry<String, String>> demset = parameters.entrySet();
        for (Map.Entry<String, String> dem : demset)
        {
            String name = (String)dem.getKey();
            String value = (String)dem.getValue();
            if ((name != null) && (value != null) && (!value.isEmpty()))
            {
                if (hasParam) {
                    postData.append("&");
                }
                postData.append(name);
                postData.append("=");
                try
                {
                    postData.append(URLEncoder.encode(value, "UTF-8"));
                }
                catch (UnsupportedEncodingException e)
                {
                    e.printStackTrace();
                }
                hasParam = true;
            }
        }
        return postData.toString();
    }
}
