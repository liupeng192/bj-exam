package cn.xdf.code.dao;

import cn.xdf.code.bean.ConfirmCode;
import cn.xdf.framework.dao.BaseDao;
import org.springframework.stereotype.Repository;

/**
 * @author liupeng
 * @date 2020/7/31-17:38
 **/
@Repository
public class ConfirmCodeDao extends BaseDao<ConfirmCode>
{}