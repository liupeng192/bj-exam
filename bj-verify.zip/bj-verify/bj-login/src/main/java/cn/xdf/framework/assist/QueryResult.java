package cn.xdf.framework.assist;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@SuppressWarnings("serial")
public class QueryResult<T> implements Serializable{  
	  
    public List<T> list = new ArrayList<T>(); // 结果集  
    public int totalRow; // 总记录数  
    public int pageNo  = 1; //页数
    public int defaultPageSize = 20;
    public int maxPage = 0;	//最大页数
    
    public int pageSize = defaultPageSize;
    
    public Map<String,Object> extMap = new HashMap<String,Object>();

    
    public QueryResult() {}  
    public QueryResult(List<T> list, int totalRow) {  
        this.list = list;  
        this.totalRow = totalRow;  
    }
    public QueryResult(List<T> list, int totalRow,int pageNo,int pageSize) {  
        this.list = list;  
        this.totalRow = totalRow;  
        this.pageNo = pageNo;
        this.pageSize = pageSize;
        
        setMaxPageTotal(totalRow);
    }
    
    public void setMaxPageTotal(int total) {
        if (total > 0) {
            this.setMaxPage((int) ((total - 1) / pageSize) + 1);
        }else {
        	this.setMaxPage(1);
		}
    }
    
	public int getMaxPage() {
		return maxPage;
	}
	public void setMaxPage(int maxPage) {
		this.maxPage = maxPage;
	}
	public List<T> getList() {
		return list;
	}
	public void setList(List<T> list) {
		this.list = list;
	}
	public int getTotalRow() {
		return totalRow;
	}
	public void setTotalRow(int totalRow) {
		this.totalRow = totalRow;
	}
	public int getPageNo() {
		return pageNo;
	}
	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}
	public int getDefaultPageSize() {
		return defaultPageSize;
	}
	public void setDefaultPageSize(int defaultPageSize) {
		this.defaultPageSize = defaultPageSize;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	public Map<String, Object> getExtMap() {
		return extMap;
	}
	public void setExtMap(Map<String, Object> extMap) {
		this.extMap = extMap;
	}
}  