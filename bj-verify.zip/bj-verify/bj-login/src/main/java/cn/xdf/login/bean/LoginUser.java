package cn.xdf.login.bean;

import cn.xdf.rmi.data.U2vmData;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author liupeng
 * @date 2020/7/31-16:32
 **/
public class LoginUser implements Serializable {
    private String userName;
    private String passWord;
    private String mobile;
    private String statCode;
    private String userId;
    private String sutCode;
    private U2vmData u2vmData;
    private String message;
    private int status = 0;
    private List<String> userCodes = new ArrayList();

    public String getUserName()
    {
        return this.userName;
    }

    public void setUserName(String userName)
    {
        this.userName = userName;
    }

    public String getPassWord()
    {
        return this.passWord;
    }

    public void setPassWord(String passWord)
    {
        this.passWord = passWord;
    }

    public String getMobile()
    {
        return this.mobile;
    }

    public void setMobile(String mobile)
    {
        this.mobile = mobile;
    }

    public String getSutCode()
    {
        return this.sutCode;
    }

    public void setSutCode(String sutCode)
    {
        this.sutCode = sutCode;
    }

    public U2vmData getU2vmData()
    {
        return this.u2vmData;
    }

    public void setU2vmData(U2vmData u2vmData)
    {
        this.u2vmData = u2vmData;
    }

    public String getMessage()
    {
        return this.message;
    }

    public void setMessage(String message)
    {
        this.message = message;
    }

    public int getStatus()
    {
        return this.status;
    }

    public void setStatus(int status)
    {
        this.status = status;
    }

    public List<String> getUserCodes()
    {
        return this.userCodes;
    }

    public void setUserCodes(List<String> userCodes)
    {
        this.userCodes = userCodes;
    }

    public String getUserId()
    {
        return this.userId;
    }

    public void setUserId(String userId)
    {
        this.userId = userId;
    }

    public String getStatCode()
    {
        return this.statCode;
    }

    public void setStatCode(String statCode)
    {
        this.statCode = statCode;
    }
}
