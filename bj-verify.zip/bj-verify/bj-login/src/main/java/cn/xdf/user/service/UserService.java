package cn.xdf.user.service;

import cn.xdf.user.bean.UserInfo;

/**
 * @author liupeng
 * @date 2020/7/31-17:14
 **/
public interface UserService {
    public  UserInfo getUserInfo(UserInfo paramUserInfo);

    public  void addUserInfo(UserInfo paramUserInfo);
}
