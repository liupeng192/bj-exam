package cn.xdf.token;

import cn.xdf.rmi.data.U2AccessTokenDto;

import java.util.Date;

/**
 * @author liupeng
 * @date 2020/7/31-16:11
 **/
public class Token {
    private U2AccessTokenDto u2AccessToken;
    private Date tokenExpireTime;

    public Token(U2AccessTokenDto u2AccessToken)
    {
        this.u2AccessToken = u2AccessToken;
    }

    public Token(U2AccessTokenDto u2AccessToken, Date tokenExpireTime)
    {
        this.u2AccessToken = u2AccessToken;
        this.tokenExpireTime = tokenExpireTime;
    }

    public U2AccessTokenDto getU2AccessToken()
    {
        return this.u2AccessToken;
    }

    public void setU2AccessToken(U2AccessTokenDto u2AccessToken)
    {
        this.u2AccessToken = u2AccessToken;
    }

    public Date getTokenExpireTime()
    {
        return this.tokenExpireTime;
    }

    public void setTokenExpireTime(Date tokenExpireTime)
    {
        this.tokenExpireTime = tokenExpireTime;
    }
}
