package cn.xdf.login.dao;

import cn.xdf.framework.dao.BaseDao;
import cn.xdf.login.bean.LoginBean;
import cn.xdf.utils.StringUtils;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

/**
 * @author liupeng
 * @date 2020/7/31-16:58
 **/

@Repository
public class LoginUserDao  extends BaseDao<LoginBean> {
    public LoginBean getLoginUserByTell(String mobile) {
        String sql = "select * from bj_tb_login where mobile='" + mobile + "'";
        return (LoginBean) queryForObject(sql, new Object[]{LoginBean.class});
    }

    public LoginBean getLoginUserByUserName(String mobile) {
        String sql = "select * from bj_tb_login where mobile='" + mobile + "'";
        return (LoginBean) queryForObject(sql, new Object[]{LoginBean.class});
    }

    public LoginBean getLoginUser(LoginBean user) {
        String sql = "SELECT loginId as id, mobile, userName, passWord, token, targetUrl, createTime, lastLoginTime FROM bj_tb_login WHERE 1 = 1 ";

        List<Object> args = new ArrayList();
        if (StringUtils.isNotBlank(user.getMobile())) {
            sql = sql + " AND (mobile=? or userName=?)";
            args.add(user.getMobile());
            args.add(user.getMobile());
        } else if (StringUtils.isNotBlank(user.getUserName())) {
            sql = sql + "AND userName = ? ";
            args.add(user.getUserName());
        }
        sql = sql + "ORDER BY createTime desc";
        return (LoginBean) super.queryForObject(sql, args.toArray(new Object[args.size()]));
    }
}