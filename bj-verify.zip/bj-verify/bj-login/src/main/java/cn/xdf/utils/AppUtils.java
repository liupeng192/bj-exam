package cn.xdf.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import net.sf.json.xml.XMLSerializer;

public class AppUtils {

	
	public static String genUUID() {
		return UUID.randomUUID().toString().toUpperCase();
	}

	public static String getBaseDir() {
		String path = System.getProperty("user.dir");
		return path;
	}

	public static String getSourceDir() {
		String baseDir = getBaseDir();
		String resourceDir = baseDir + File.separator + "source";
		return resourceDir;
	}

	public static <T> T getInstance(Class<T> clazz) {
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"spring/applicationContext.xml");
		return (T) context.getBean(clazz);
	}
	
	public static <T> T getInstance(String bean) {
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"spring/applicationContext.xml");
		return (T) context.getBean(bean);
	}

	public static String convertIds(String ids) {
		String newIDs= "";
		String[] idArr = ids.split(",");
		for (String id : idArr) {			
			newIDs = newIDs + "'" + org.apache.commons.lang.StringEscapeUtils.escapeSql(id) + "'" + ",";
		}
		newIDs = newIDs.substring(0, newIDs.length() - 1);
		return newIDs;
	}

	public static String convertIds(List<String> list) {		
		String ids = "";
		for (String id : list) {			
			ids = ids + "'" + org.apache.commons.lang.StringEscapeUtils.escapeSql(id) + "'" + ",";
		}
		ids = ids.substring(0, ids.length() - 1);
		return ids;
	}
	
	
	public static String convertIds(JSONArray list) {
		String ids = "";
		for (Object object : list) {
			String id = object.toString();			
			ids = ids + "'" + id + "'" + ",";
		}
	
		ids = ids.substring(0, ids.length() - 1);
		return ids;
	}
	

	public static List<String> convertIds2List(String ids) {
		List<String> list = new ArrayList<String>();
		if (StringUtils.isBlank(ids)) {
			return list;
		} else {
			String[] idArr = ids.split(",");
			for (String id : idArr) {
				list.add(id);
			}
			return list;
		}
	}

	public static String getIp(HttpServletRequest request) throws IOException {
		String ipFromNginx = getHeader(request, "X-Forwarded-For");//X-Real-IP,X-Forwarded-For
		return StringUtils.isEmpty(ipFromNginx) ? request.getRemoteAddr()
				: ipFromNginx;
	}

	private static String getHeader(HttpServletRequest request, String headName) {
		String value = request.getHeader(headName);
		return !StringUtils.isBlank(value)
				&& !"unknown".equalsIgnoreCase(value) ? value : "";
	}

	@SuppressWarnings("rawtypes")
	public static Map convertObj2Map(Object obj) {
		try {
			String json = JSONObject.toJSONString(obj);
			return JSONObject.parseObject(json, Map.class);
		} catch (Exception e) {
			return new LinkedHashMap();
		}
	}

	public static String getCookie(HttpServletRequest req, String key) {
		if (StringUtils.isBlank(key)) {
			return null;
		}
		Cookie[] cookies = req.getCookies();
		for (Cookie cookie : cookies) {
			String name = cookie.getName();
			if (key.equals(name)) {
				return cookie.getValue();
			}
		}
		return null;
	}

	/**
	 * 提取答案
	 * 
	 * @param str
	 * @return
	 */
	public static String exactLetter(String str) {
		StringBuffer sb = new StringBuffer();

		if (StringUtils.isBlank(str)) {
			return "";
		}
		Pattern p = Pattern.compile("[a-zA-Z]");
		Matcher m = p.matcher(str);
		while (m.find()) {
			String group = m.group().toUpperCase();
			sb.append(group).append(",");
		}
		String result = sb.toString();
		if (result.length() >= 1) {
			result = result.substring(0, result.length() - 1);
		}

		return result;
	}

	public static String formatTime(int second) {
		int h = 0;
		int d = 0;
		int s = 0;
		int temp = second % 3600;
		if (second > 3600) {
			h = second / 3600;
			if (temp != 0) {
				if (temp > 60) {
					d = temp / 60;
					if (temp % 60 != 0) {
						s = temp % 60;
					}
				} else {
					s = temp;
				}
			}
		} else {
			d = second / 60;
			if (second % 60 != 0) {
				s = second % 60;
			}
		}

		return h + "时" + d + "分" + s + "秒";
	}


	public static String parseUrlParam(String url, String key) {
		try {
			URL urlObj = new URL(url);
			String query = urlObj.getQuery();
			if (StringUtils.isBlank(query)) {
				return null;
			}
			String[] paramPairs = query.split("&");
			for (String pp : paramPairs) {
				String[] param = pp.split("=");
				if (param[0].equals(key)) {
					return param[1];
				}
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static String clearHTML(String content) {
		if (StringUtils.isNotBlank(content)) {
			return content.replaceAll("<[^>]*>", "");
		} else {
			return "";
		}
	}


	public static double getNumericRate(double numerator, double denominator) {
		double usageRate = 0;

		if (numerator != 0 && denominator != 0) {
			usageRate = (double) numerator / denominator;
			usageRate = gainUsageRate(usageRate);
		}

		return usageRate;
	}

	private static double gainUsageRate(double data) {
		BigDecimal b = new BigDecimal(data);
		return b.setScale(4, BigDecimal.ROUND_HALF_UP).doubleValue();
	}
	
	public static double gainReservationNumber(double data, int reservationNumber) {
		BigDecimal b = new BigDecimal(data);
		return b.setScale(reservationNumber, BigDecimal.ROUND_HALF_UP).doubleValue();
	}

	public static String getNumericRatePercent(double numerator,
			double denominator) {
		return ((float) (getNumericRate(numerator, denominator) * 100)) + "%";
	}

	public static float getNumericRatePercentFloat(double numerator,
			double denominator) {
		return ((float) (getNumericRate(numerator, denominator) * 100));
	}

	public static String sToMinSec(int second) {
		int m = 0;
		int s = 0;
		int temp = second % 60;

		if (temp > 0) {
			s = temp;
		}

		m = second / 60;

		return (m < 10 ? "0" + m : m) + ":" + (s < 10 ? "0" + s : s);
	}


	public static String tran2JavaType(String sqlType) {
		if (sqlType.equalsIgnoreCase("bit")) {
			return "Boolean";
		} else if (sqlType.equalsIgnoreCase("tinyint")) {
			return "Byte";
		} else if (sqlType.equalsIgnoreCase("smallint")) {
			return "Short";
		} else if (sqlType.equalsIgnoreCase("int")
				|| sqlType.equalsIgnoreCase("int identity")) {
			return "Integer";
		} else if (sqlType.equalsIgnoreCase("bigint")) {
			return "Long";
		} else if (sqlType.equalsIgnoreCase("float")) {
			return "Float";
		} else if (sqlType.equalsIgnoreCase("decimal")
				|| sqlType.equalsIgnoreCase("numeric")
				|| sqlType.equalsIgnoreCase("real")
				|| sqlType.equalsIgnoreCase("money")
				|| sqlType.equalsIgnoreCase("smallmoney")) {
			return "Double";
		} else if (sqlType.equalsIgnoreCase("varchar")
				|| sqlType.equalsIgnoreCase("char")
				|| sqlType.equalsIgnoreCase("nvarchar")
				|| sqlType.equalsIgnoreCase("nchar")
				|| sqlType.equalsIgnoreCase("text")) {
			return "String";
		} else if (sqlType.equalsIgnoreCase("datetime")) {
			return "Date";
		} else if (sqlType.equalsIgnoreCase("image")) {
			return "Blod";
		}
		return null;
	}

	public static List<String> convert2List(JSONArray ids) {
		List<String> list = new ArrayList<String>();
		for (int i = 0; i < ids.size(); i++) {
			list.add(ids.getString(i));
		}
		return list;
	}

	
	/** 
     * AES加密 
     * @param content 待加密的内容 
     * @param encryptKey 加密密钥 
     * @return 加密后的byte[] 
     * @throws Exception 
     */ 
	public static String AesEncrypt(String content,String encryptKey) {
		if(StringUtils.isBlank(content)){
			return "";
		}
		try {
			return EncodeUtils.encrypt(content,encryptKey);
		} catch (Throwable e) {
			e.printStackTrace();
		}
		
		return "";
	}

	/**
	 * 对信息解密
	 * 
	 * @param encryptContent
	 * @return
	 */
	public static String AesDecrypt(String encryptContent, String decryptKey) {
		if(StringUtils.isBlank(encryptContent)){
			return "";
		}
		try {
			return EncodeUtils.decrypt(encryptContent,decryptKey);
		} catch (Throwable e) {
			e.printStackTrace();
		}
		
		return "";
	}
	
	
	
	/**
	 * 用户手机号码的加密和解密
	 */
	public static final String[] muben = new String[]{"h","b","i","c","x","w","e","y","n","g"};//母本
	
	public static String encrypt(String content,String key){
		try{
			StringBuffer result = new StringBuffer();
			
			String[] strs = content.split("");
			for(String str:strs){
				if(StringUtils.isNotBlank(str)){ 
					result.append(muben[Integer.parseInt(str)]);
				}
			}
			content = result+key;
			return EncodeUtils.encodeBase64(content.getBytes());
		}catch(Exception e){
			return "";
		}
	}
	
	public static String decrypt(String content,String key){
		if(StringUtils.isBlank(content)){
			return "";
		}
		
		try{
			StringBuffer result = new StringBuffer();
			
			byte[] bytes = EncodeUtils.decodeBase64(content);
			content = new String(bytes);
			content = content.substring(0,content.indexOf(key));
			
			String[] strs = content.split("");
			for(String str:strs){
				if(StringUtils.isNotBlank(str)){ 
					for(int i=0;i<muben.length;i++){
						if(muben[i].equals(str)){
							result.append(i);
						}
					}
				}
			}
			return result.toString();
		}catch(Exception e){
			return "";
		}
	}
	
	/**
	 * 检测是否是移动平台
	 * @param agent
	 * @return
	 */
	public static boolean checkMobilePlatForm(String agent){
		boolean result = false;
		if(StringUtils.isBlank(agent)){
			return result;
		}
		
		String[] list = new String[]{
			"nokia", "sony", "ericsson", "mot", "samsung", "htc", "sgh", "lg", "sharp", "sie-",
			"philips", "panasonic", "alcatel", "lenovo", "iphone", "ipod", "blackberry", "meizu", 
			"android", "netfront", "symbian", "ucweb", "windowsce", "palm", "operamini", 
			"operamobi", "opera mobi", "openwave", "nexusone", "cldc", "midp", "wap", "mobile"};
		
		agent = agent.toLowerCase();
		for(String item:list){
			if(agent.indexOf(item)>-1){
				result = true;
				break;
			}
		}
		return result;
	}
	
	
	/**
	 * 检测是否是微信平台
	 * @param agent
	 * @return
	 */
	public static boolean checkWeiXinPlatForm(String agent){
		boolean result = false;
		String[] list = new String[]{"micromessenger"};
		
		agent = agent.toLowerCase();
		for(String item:list){
			if(agent.indexOf(item)>-1){
				result = true;
				break;
			}
		}
		return result;
	}
	
	
	/**
	 * 检测是否是设备平台
	 * @param agent
	 * @return
	 */
	public static boolean checkDevicePlatForm(String agent,String[] agents){
		boolean result = false;
		if(StringUtils.isBlank(agent)){
			return result;
		}
		agent = agent.toLowerCase();
		for(String item:agents){
			if(agent.indexOf(item.toLowerCase())>-1){
				result = true;
				break;
			}
		}
		return result;
	}
	
	
	
 
	public static String tranDataXML(Map<String, String> map) {
		StringBuffer sb = new StringBuffer();
		sb.append("<xml>");
		Set<String> keys = map.keySet();
		for (String key : keys) {
			sb.append("<").append(key).append(">").append(map.get(key))
					.append("</").append(key).append(">");
		}
		sb.append("</xml>");
		return sb.toString();
	}
	public static String inputStream2String(InputStream in) {
		try{
			if(in == null)
	            return "";
	        
	        StringBuffer out = new StringBuffer();
	        byte[] b = new byte[4096];
	        for (int n; (n = in.read(b)) != -1;) {
	            out.append(new String(b, 0, n, "UTF-8"));
	        }
	        return out.toString();
		}catch(Exception e){
			e.printStackTrace();
		}
		return "";
    }
	
	
	public static boolean isAjaxRequest(HttpServletRequest request){  
	    String header = request.getHeader("X-Requested-With");  
	    boolean isAjax = "XMLHttpRequest".equals(header) ? true:false;  
	    return isAjax;  
	}

	public static int parseInt(String str) throws Exception {
		if(StringUtils.isBlank(str)){
			return 0;
		}else{
			return Integer.parseInt(str);
		}
	}

	/**
	 * 
	* @Title: getCurrentTime
	* @Description: 获取当前时间
	* @param @return    参数
	* @return Date    返回类型
	* @throws
	 */
	public static Date getCurrentTime() {
		return new Date();
	}

	/**
	* @Title: toJSONString
	* @Description: JSON转换工具类
	* @param @param userAnswers    参数
	* @return void    返回类型
	* @throws
	*/
	public static String toJSONString(Object obj) {
		return JSONObject.toJSONString(obj);
	}
	
	public static void logReq(HttpServletRequest req) {
		String uri = AppUtils.buildReqURI(req);
		Log.info(uri);
	}
	
	public static String buildReqURI(HttpServletRequest req){
		String uri = req.getRequestURI(); 
		String query = req.getQueryString();
		if(StringUtils.isNotBlank(query)){
			uri = uri+"?"+query;
		}
		return uri;
	}

	public static JSONObject parseObject(String str) {
		if(StringUtils.isBlank(str)){
			return new JSONObject();
		}else{
			return JSONObject.parseObject(str);
		}
	}

	
	public static float formatFloat(float number,String format) {
		return Float.parseFloat(String.format(format,number));
	}
	
	
	public static float formatFloat(float number) {
		return AppUtils.formatFloat(number, "%.2f");
	}
	
	public static double formatDouble(double number,String format) {
		return Double.parseDouble(String.format(format,number));
	}
	
	public static double formatDouble(double number) {
		return AppUtils.formatDouble(number,"%.2f");
	}
	
	public static double floatToDouble(float number) {
		return Double.parseDouble(String.valueOf(number));
	}
	
	/**
	 * 
	 * @Description: 获取服务器协议+域名+项目名(eg: http://bj.xdf.cn/tps/gwots)
	 *  
	 * @Title: getHostServerName    
	 * @param req
	 * @return	String
	 */
	public static String getHostServerName(HttpServletRequest req){
		String hostServerName = req.getScheme()+"://"+req.getServerName()+req.getContextPath();
		return hostServerName;
	}
	
	/**
	 * 
	 * @Description: 过滤掉字符串中的特殊字符
	 *  
	 * @Title: filterSpecialCharacter    
	 * @param string
	 * @return	String
	 * @throws PatternSyntaxException
	 */
    public static String filterSpecialCharacter(String string) throws PatternSyntaxException {
    	if(StringUtils.isBlank(string)){
    		return string;
    	}
        // 只允许字母和数字 // String regEx = "[^a-zA-Z0-9]";
        // 清除掉所有特殊字符
        String regEx = "[`~!@#$%^&*()+=|{}':;',\\[\\].·<>/?~！@#￥%……&*（）——+|{}【】《》‘；：”“’。，、？]";
        Pattern p = Pattern.compile(regEx);
        Matcher m = p.matcher(string);
        
        return m.replaceAll("").trim();
   }
  
}