package cn.xdf.rmi.data;

import java.io.Serializable;

/**
 * @author liupeng
 * @date 2020/7/31-16:09
 **/
public class U2AccessTokenDto implements Serializable {
    private String access_token;
    private int expires_in;
    private String refresh_token;
    private String userId;
    private String nickName;
    private String userName;
    private String email;
    private String mobile;
    private String stuCode;

    public String getAccess_token()
    {
        return this.access_token;
    }

    public void setAccess_token(String access_token)
    {
        this.access_token = access_token;
    }

    public int getExpires_in()
    {
        return this.expires_in;
    }

    public void setExpires_in(int expires_in)
    {
        this.expires_in = expires_in;
    }

    public String getRefresh_token()
    {
        return this.refresh_token;
    }

    public void setRefresh_token(String refresh_token)
    {
        this.refresh_token = refresh_token;
    }

    public String getUserId()
    {
        return this.userId;
    }

    public void setUserId(String userId)
    {
        this.userId = userId;
    }

    public String getNickName()
    {
        return this.nickName;
    }

    public void setNickName(String nickName)
    {
        this.nickName = nickName;
    }

    public String getUserName()
    {
        return this.userName;
    }

    public void setUserName(String userName)
    {
        this.userName = userName;
    }

    public String getEmail()
    {
        return this.email;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }

    public String getMobile()
    {
        return this.mobile;
    }

    public void setMobile(String mobile)
    {
        this.mobile = mobile;
    }

    public String getStuCode()
    {
        return this.stuCode;
    }

    public void setStuCode(String stuCode)
    {
        this.stuCode = stuCode;
    }
}
