package cn.xdf;

import cn.xdf.config.ConfigMssage;
import cn.xdf.login.filter.LoginFilter;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
@SpringBootApplication
public class AppLogin  {
    @Bean(initMethod = "refreshConfig",destroyMethod = "destroy")
    public ConfigMssage getConfigMessage(){
        return new ConfigMssage();
    }
    @Bean
    public FilterRegistrationBean registFilter() {
        FilterRegistrationBean registration = new FilterRegistrationBean();
        registration.setFilter(new LoginFilter());
        registration.addUrlPatterns("/*");
        registration.setName("LoginVerifyFilter");
        registration.setOrder(1);
        return registration;
    }
    public static void main(String[] args) {
        SpringApplication.run(AppLogin.class,args);
    }
}
