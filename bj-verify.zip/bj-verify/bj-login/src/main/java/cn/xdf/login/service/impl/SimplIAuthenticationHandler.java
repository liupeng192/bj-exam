package cn.xdf.login.service.impl;

import cn.xdf.code.service.UserCodeService;
import cn.xdf.login.bean.Credential;
import cn.xdf.login.bean.LoginBean;
import cn.xdf.login.bean.LoginUser;
import cn.xdf.login.service.IAuthenticationHandler;
import cn.xdf.login.service.LoginUserServer;
import cn.xdf.rmi.data.U2AccessTokenDto;
import cn.xdf.rmi.data.U2vmData;
import cn.xdf.user.bean.UserInfo;
import cn.xdf.user.service.UserService;
import cn.xdf.utils.DES;
import cn.xdf.utils.Https;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import java.net.URLEncoder;
import java.util.Date;
import java.util.HashMap;
import java.util.Set;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author liupeng
 * @date 2020/7/31-17:19
 **/
@Service
public class SimplIAuthenticationHandler implements IAuthenticationHandler {
    @Autowired
    private UserService userService;
    @Autowired
    private LoginUserServer loginUserServer;
    @Override
    public LoginUser authenticate(Credential paramCredential) throws Exception {

        LoginUser loginUser = new LoginUser();
        String userName = paramCredential.getParameter("userName");
        String passWord = paramCredential.getParameter("passWord");
        String message = "";
        if (userName != null)
        {
            String loginurl = "http://wxconter.bj.xdf.cn/wechatserver/ssoLogin?loginName=USERNAME&password=PASSWORD";
            loginurl = loginurl.replace("USERNAME", URLEncoder.encode(DES.encrypt(userName)));
            loginurl = loginurl.replace("PASSWORD", URLEncoder.encode(DES.encrypt(passWord)));

            String result = Https.doGet(loginurl, new HashMap());
            JSONObject resultjson = (JSONObject) JSONObject.parse(result);
            U2AccessTokenDto accessTokenDto = (U2AccessTokenDto) JSON.parseObject(resultjson.getString("Data"), U2AccessTokenDto.class);
            String status = resultjson.get("Status").toString();
            message = resultjson.get("Message").toString();
            String loginUuid = UUID.randomUUID().toString();
            String userUuid = UUID.randomUUID().toString();
            if ((status != null) && ("1".equals(status)))
            {
                LoginBean loginBean = new LoginBean();
                UserInfo userInfo = new UserInfo();
                userInfo.setUserName(userName);
                UserInfo currInfo = this.userService.getUserInfo(userInfo);
                if (currInfo == null)
                {
                    userInfo.setId(userUuid);
                    userInfo.setUserID(accessTokenDto.getUserId());
                    userInfo.setEmail(accessTokenDto.getEmail());
                    userInfo.setMobile(accessTokenDto.getMobile());
                    userInfo.setCreateTime(new Date());
                    userInfo.setFlagModify(1);
                    this.userService.addUserInfo(userInfo);
                    loginBean.setUserLoginId(userUuid);
                }
                else
                {
                    loginBean.setUserLoginId(currInfo.getId());
                    loginBean.setCreateTime(currInfo.getCreateTime());
                }
                loginBean.setId(loginUuid);
                loginBean.setUserName(userName);
                loginBean.setPassWord(passWord);
                loginBean.setUserId(accessTokenDto.getUserId());
                loginBean.setLastLoginTime(new Date());
                this.loginUserServer.addLoginUser(loginBean);
            }
            loginUser.setStatus(1);
            loginUser.setUserName(userName);
            loginUser.setMobile(userName);
            loginUser.setMessage(message);
            loginUser.setUserId(accessTokenDto.getUserId());
            loginUser.setU2vmData((U2vmData)paramCredential.getSettedSessionValue());
            return loginUser;
        }
        loginUser.setStatus(0);
        loginUser.setMessage(message);
        return loginUser;
    }

    @Override
    public Set<String> authedSystemIds(U2AccessTokenDto paramU2AccessTokenDto) throws Exception {
        return null;
    }

    @Override
    public U2AccessTokenDto autoLogin(String paramString) {
        return null;
    }
}
