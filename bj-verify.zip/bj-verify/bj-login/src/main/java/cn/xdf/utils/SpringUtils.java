package cn.xdf.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.stereotype.Component;


/**
 * spring工具类,用于获得容器中的对象
 * @author luanhaibin
 */

@Component
public class SpringUtils implements BeanFactoryAware{
	
	private static BeanFactory beanFactory;
	
	private static final Logger logger = LoggerFactory.getLogger(SpringUtils.class);
	
	public static <T>  T getInstance(Class<T> requiredType){
		T instance = beanFactory.getBean(requiredType);
		if(instance==null){
			logger.error(requiredType+"不存在");
		}
		return instance;
	}
	
	@SuppressWarnings("unchecked")
	public static <T>  T getInstance(String bean){
		Object obj = beanFactory.getBean(bean);
		if(obj == null){
			logger.error(bean+"不存在");
		}
		T instance = (T)obj; 
		return instance;
	}
	
	public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
		SpringUtils.beanFactory = beanFactory; 
	}
}