package cn.xdf.code.dao;

import cn.xdf.code.bean.UserCode;
import cn.xdf.framework.dao.BaseDao;
import cn.xdf.utils.StringUtils;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

/**
 * @author liupeng
 * @date 2020/7/31-17:38
 **/

@Repository
public class UserCodeDao extends BaseDao<UserCode>
{
    public List<UserCode> getUserCodes(UserCode userCode)
    {
        String sql = "SELECT stucodeid, stuid, stateCode,stucode, createtime FROM bj_tb_stucode WHERE 1 = 1 ";

        List<Object> args = new ArrayList();
        if (StringUtils.isNotBlank(userCode.getUserId()))
        {
            sql = sql + "AND stuid = ? ";
            args.add(userCode.getUserId());
        }
        else if (StringUtils.isNotBlank(userCode.getUserCode()))
        {
            sql = sql + "AND stucode = ? ";
            args.add(userCode.getUserCode());
        }
        else if (StringUtils.isNotBlank(userCode.getStateCode()))
        {
            sql = sql + "AND stateCode = ? ";
            args.add(userCode.getStateCode());
        }
        else if (StringUtils.isNotBlank(userCode.getId()))
        {
            sql = sql + "AND stucodeid = ? ";
            args.add(userCode.getId());
        }
        sql = sql + "ORDER BY stucode ASC ";
        return super.queryForList(sql, args.toArray(new Object[args.size()]));
    }
}
