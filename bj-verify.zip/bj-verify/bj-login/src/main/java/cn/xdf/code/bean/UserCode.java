package cn.xdf.code.bean;

import cn.xdf.framework.annotation.Column;
import cn.xdf.framework.annotation.Id;
import cn.xdf.framework.annotation.Table;

import java.util.Date;

/**
 * @author liupeng
 * @date 2020/7/31-17:35
 **/

@Table(name="bj_tb_stucode")
public class UserCode
{
    @Id
    @Column(name="stucodeid")
    private String id;
    @Column(name="stuid")
    private String stuid;
    @Column(name="userId")
    private String userId;
    private String userName;
    private String stateCode;
    @Column(name="stucode")
    private String userCode;
    @Column(name="createtime")
    private Date createTime;

    public String getId()
    {
        return this.id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getUserId()
    {
        return this.userId;
    }

    public void setUserId(String userId)
    {
        this.userId = userId;
    }

    public String getUserCode()
    {
        return this.userCode;
    }

    public void setUserCode(String userCode)
    {
        this.userCode = userCode;
    }

    public Date getCreateTime()
    {
        return this.createTime;
    }

    public void setCreateTime(Date createTime)
    {
        this.createTime = createTime;
    }

    public String getUserName()
    {
        return this.userName;
    }

    public void setUserName(String userName)
    {
        this.userName = userName;
    }

    public String getStateCode()
    {
        return this.stateCode;
    }

    public void setStateCode(String stateCode)
    {
        this.stateCode = stateCode;
    }

    public String getStuid()
    {
        return this.stuid;
    }

    public void setStuid(String stuid)
    {
        this.stuid = stuid;
    }
}
