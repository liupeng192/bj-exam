package cn.xdf.utils;

import cn.xdf.rmi.data.BaseDictionary;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import io.netty.util.internal.StringUtil;
import org.apache.commons.codec.digest.DigestUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;
import java.util.UUID;

/**
 * @author liupeng
 * @date 2020/7/31-17:05
 **/
public class RestRemoteUtils {
    private static String appId = "bj-xdflxs";
    private static String appSecret = "f5de3383ecfe90e69dc17d112790f283";
    private static String loginUrl = "http://passport.xdf.cn/apis/usersV2.ashx";
    private static String loginAppId = "2109";
    private static String loginAppKey = "u2k-4051-8d9a-a015bb4774c2";
    private static String url3 = "http://ztapi.xdf.cn/usercenter/v2/accounts/students";

    public static String queryU2UserIdByEmailV5(String mail)
            throws IOException
    {
        String method = "GetU2UserIdByEmailV5";
        String guid = UUID.randomUUID().toString();
        String signText = String.valueOf(method + loginAppId + guid + mail + loginAppKey).toLowerCase();
        String sign = DigestUtils.md5Hex(signText);

        BaseDictionary<String, String> param = new BaseDictionary();
        param.put("method", method);
        param.put("appid", loginAppId);
        param.put("email", mail);
        param.put("guid", guid);
        param.put("sign", sign);

        String result = Https.doPost(loginUrl, param);

        String uid = "";
        if (StringUtils.isBlank(result)) {
            return uid;
        }
        return result;
    }

    public static String queryU2UserIdByTellV5(String tell)
            throws Exception
    {
        String method = "GetU2UserIdByMobileV5";
        String guid = UUID.randomUUID().toString();
        String signText = String.valueOf(method + loginAppId + guid + tell + loginAppKey).toLowerCase();
        String sign = DigestUtils.md5Hex(signText);

        BaseDictionary<String, String> param = new BaseDictionary();
        param.put("method", method);
        param.put("appid", loginAppId);
        param.put("mobile", tell);
        param.put("guid", guid);
        param.put("sign", sign);

        String result = Https.doPost(loginUrl, param);

        String uid = "";
        if (StringUtils.isEmpty(result)) {
            return uid;
        }
        if (result.indexOf("手机格式不正确") != -1) {
            return uid;
        }
        return result;
    }

    public static ArrayList<String> queryStudentCode(String userId, String accessToken)
            throws Exception
    {
        ArrayList<String> codes = new ArrayList();
        if (StringUtils.isEmpty(userId)) {
            return codes;
        }
        TreeMap<String, String> params = new TreeMap();
        params.put("userId", userId);
        params.put("appId", appId);
        String queryStr = getQuery(params);
        String sign = verifySign(url3 + "?" + queryStr);
        HashMap<String, Object> headers = new HashMap();
        headers.put("appId", appId);
        if (StringUtils.isEmpty(accessToken)) {
            headers.put("sign", sign);
        } else {
            headers.put("accessToken", accessToken);
        }
        String result = Https.doMapHeaderGet(url3, params, headers);
        if (!StringUtils.isEmpty(result))
        {
            JSONObject json = JSONObject.parseObject(result);
            if (json.getIntValue("status") == 1)
            {
                JSONArray rows = json.getJSONObject("data").getJSONArray("rows");
                for (int i = 0; i < rows.size(); i++)
                {
                    JSONArray studentCodes = rows.getJSONObject(i).getJSONArray("studentCodes");
                    for (int j = 0; j < studentCodes.size(); j++)
                    {
                        JSONObject code = studentCodes.getJSONObject(j);
                        if (code.getIntValue("schoolId") == 1) {
                            codes.add(code.getString("studentCode"));
                        }
                    }
                }
            }
        }
        return codes;
    }

    private static String verifySign(String data)
    {
        ApiMac apiMac = new ApiMac(appSecret);
        String verifySign = "";
        try
        {
            verifySign = apiMac.sign(data);
        }
        catch (Exception localException) {}
        return verifySign;
    }

    private static String getQuery(TreeMap<String, String> param)
    {
        StringBuffer sb = new StringBuffer();
        for (String key : param.keySet()) {
            sb.append(key + "=" + (String)param.get(key) + "&");
        }
        String result = sb.toString();
        if (result.length() > 0) {
            result = result.substring(0, result.length() - 1);
        }
        return result;
    }
}
