package cn.xdf.user.bean;

import cn.xdf.framework.annotation.Id;
import cn.xdf.framework.annotation.Table;

import java.io.Serializable;
import java.util.Date;

/**
 * @author liupeng
 * @date 2020/7/31-17:13
 **/

@Table(name="bj_tb_user")
public class UserInfo
        implements Serializable
{
    @Id
    private String id;
    private String userID;
    private String xdfUserID;
    private String userName;
    private String passWord;
    private String mobile;
    private String email;
    private String nickName;
    private int flagModify;
    private Date createTime;

    public String getId()
    {
        return this.id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getUserName()
    {
        return this.userName;
    }

    public void setUserName(String userName)
    {
        this.userName = userName;
    }

    public String getPassWord()
    {
        return this.passWord;
    }

    public void setPassWord(String passWord)
    {
        this.passWord = passWord;
    }

    public String getXdfUserID()
    {
        return this.xdfUserID;
    }

    public void setXdfUserID(String xdfUserID)
    {
        this.xdfUserID = xdfUserID;
    }

    public String getMobile()
    {
        return this.mobile;
    }

    public void setMobile(String mobile)
    {
        this.mobile = mobile;
    }

    public String getEmail()
    {
        return this.email;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }

    public String getNickName()
    {
        return this.nickName;
    }

    public void setNickName(String nickName)
    {
        this.nickName = nickName;
    }

    public int getFlagModify()
    {
        return this.flagModify;
    }

    public void setFlagModify(int flagModify)
    {
        this.flagModify = flagModify;
    }

    public String getUserID()
    {
        return this.userID;
    }

    public void setUserID(String userID)
    {
        this.userID = userID;
    }

    public Date getCreateTime()
    {
        return this.createTime;
    }

    public void setCreateTime(Date createTime)
    {
        this.createTime = createTime;
    }
}
