package cn.xdf.framework.assist;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.alibaba.fastjson.JSONObject;

public class FerryInfo {
	public boolean success = true;
	public String gridHTML = null;
	public Object result = new JSONObject();
	public Map<String, Object> extMap = new HashMap();
	public ErrObject errObject = new ErrObject();

	public FerryInfo setSuccess(boolean success)
	{
		this.success = success;
		return this;
	}

	public FerryInfo setResult(Object result)
	{
		this.result = result;
		return this;
	}

	public FerryInfo setGridHTML(String gridHTML)
	{
		this.gridHTML = gridHTML;
		return this;
	}

	public FerryInfo setErrCode(String errCode)
	{
		ErrObject errObject = getErrObject();
		errObject.setErrCode(errCode);
		return this;
	}

	public FerryInfo setErrMsg(String errMsg)
	{
		ErrObject errObject = getErrObject();
		errObject.setErrMess(errMsg);
		return this;
	}

	public FerryInfo setErrDetail(String errDetail)
	{
		ErrObject errObject = getErrObject();
		errObject.setErrDetail(errDetail);
		return this;
	}

	public Object getResult()
	{
		return this.result;
	}

	public ErrObject getErrObject()
	{
		return this.errObject;
	}

	public void setErrObject(ErrObject errObject)
	{
		this.errObject = errObject;
	}

	public String getGridHTML()
	{
		return this.gridHTML;
	}

	public void setErrObject(String errCode)
	{
		setErrObject(errCode, null, null);
	}

	public void setErrObject(String errCode, String errMess)
	{
		setErrObject(errCode, errMess, null);
	}

	public void setErrObject(String errCode, String errMess, String errDetail)
	{
		ErrObject errObject = new ErrObject();
		if (StringUtils.isNotBlank(errCode)) {
			errObject.errCode = errCode;
		}
		if (StringUtils.isNotBlank(errMess)) {
			errObject.errMess = errMess;
		}
		if (StringUtils.isNotBlank(errDetail)) {
			errObject.errDetail = errDetail;
		}
		this.errObject = errObject;
	}

	public static FerryInfo Success(String html)
	{
		FerryInfo info = new FerryInfo();
		info.gridHTML = html;
		return info;
	}

	public static FerryInfo Success(Object data)
	{
		FerryInfo info = new FerryInfo();
		info.result = data;
		return info;
	}

	public static FerryInfo Success(Object data, String html)
	{
		FerryInfo info = new FerryInfo();
		info.result = data;
		info.gridHTML = html;
		return info;
	}

	public static FerryInfo Error(String errCode, String errMess, String errDetail)
	{
		FerryInfo info = new FerryInfo();
		info.setErrObject(errCode, errMess, errDetail);
		return info;
	}

	public Map<String, Object> getExtMap()
	{
		return this.extMap;
	}

	public void setExtMap(Map<String, Object> extMap)
	{
		this.extMap = extMap;
	}
}