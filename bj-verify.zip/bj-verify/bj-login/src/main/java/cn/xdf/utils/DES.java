package cn.xdf.utils;

import java.io.IOException;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Base64.Encoder;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

/**
 * @author liupeng
 * @date 2020/7/31-17:21
 **/
public class DES {
    private static byte[] desKey = "74776d9c4bda41969bcaa9dac2e9c38a".getBytes();

    public static byte[] desEncrypt(byte[] plainText)
            throws Exception
    {
        SecureRandom sr = new SecureRandom();
        byte[] rawKeyData = desKey;
        DESKeySpec dks = new DESKeySpec(rawKeyData);
        SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
        SecretKey key = keyFactory.generateSecret(dks);
        Cipher cipher = Cipher.getInstance("DES");
        cipher.init(1, key, sr);
        byte[] data = plainText;
        byte[] encryptedData = cipher.doFinal(data);
        return encryptedData;
    }

    public static byte[] desDecrypt(byte[] encryptText)
            throws Exception
    {
        SecureRandom sr = new SecureRandom();
        byte[] rawKeyData = desKey;
        DESKeySpec dks = new DESKeySpec(rawKeyData);
        SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
        SecretKey key = keyFactory.generateSecret(dks);
        Cipher cipher = Cipher.getInstance("DES");
        cipher.init(2, key, sr);
        byte[] encryptedData = encryptText;
        byte[] decryptedData = cipher.doFinal(encryptedData);
        return decryptedData;
    }

    public static String encrypt(String input)
            throws Exception
    {
        return base64Encode(desEncrypt(input.getBytes()));
    }

    public static String decrypt(String input)
            throws Exception
    {
        byte[] result = base64Decode(input);
        return new String(desDecrypt(result));
    }

    public static String base64Encode(byte[] s)
    {
        if (s == null) {
            return null;
        }
        Base64.Encoder encoder = Base64.getEncoder();
        return encoder.encodeToString(s);
    }

    public static byte[] base64Decode(String s)
            throws IOException
    {
        if (s == null) {
            return null;
        }
        Base64.Decoder decoder = Base64.getDecoder();
        byte[] b = decoder.decode(s);
        return b;
    }

    public static void main(String[] args)
            throws Exception
    {}
}
