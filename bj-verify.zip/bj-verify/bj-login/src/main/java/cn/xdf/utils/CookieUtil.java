package cn.xdf.utils;

import java.net.URLEncoder;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

/**
 * @author liupeng
 * @date 2020/7/31-16:28
 **/
public class CookieUtil {
    public static void addCookie(HttpServletResponse response, String name, String value)
    {
        if ((StringUtils.isBlank(name)) || (StringUtils.isBlank(value))) {
            return;
        }
        try
        {
            name = URLEncoder.encode(name, "utf-8");
            value = URLEncoder.encode(value, "utf-8");
        }
        catch (UnsupportedEncodingException e)
        {
            e.printStackTrace();
        }
        Cookie cookie = new Cookie(name.trim(), value.trim());
        cookie.setPath("/");
        cookie.setMaxAge(2592000);
        response.addCookie(cookie);
    }

    public static void addCookie(HttpServletResponse response, String name, String value, String path, Integer maxAge)
    {
        if ((StringUtils.isBlank(name)) || (StringUtils.isBlank(value))) {
            return;
        }
        try
        {
            name = URLEncoder.encode(name, "utf-8");
            value = URLEncoder.encode(value, "utf-8");
        }
        catch (UnsupportedEncodingException e)
        {
            e.printStackTrace();
        }
        if (StringUtils.isBlank(path)) {
            path = "/";
        }
        if (maxAge == null) {
            maxAge = Integer.valueOf(2592000);
        }
        Cookie cookie = new Cookie(name.trim(), value.trim());
        cookie.setPath(path);
        cookie.setMaxAge(maxAge.intValue());
        response.addCookie(cookie);
    }

    public static void addCookie(HttpServletResponse response, String name, String value, int maxAge)
    {
        if ((name == null) || (value == null)) {
            return;
        }
        try
        {
            name = URLEncoder.encode(name, "utf-8");
            value = URLEncoder.encode(value, "utf-8");
        }
        catch (UnsupportedEncodingException e)
        {
            e.printStackTrace();
        }
        Cookie cookie = new Cookie(name.trim(), value.trim());
        cookie.setPath("/");
        cookie.setMaxAge(maxAge);
        response.addCookie(cookie);
    }

    public static void editCookie(HttpServletRequest request, HttpServletResponse response, String name, String value)
    {
        if ((name == null) || (value == null)) {
            return;
        }
        try
        {
            name = URLEncoder.encode(name, "utf-8");
            value = URLEncoder.encode(value, "utf-8");
        }
        catch (UnsupportedEncodingException e)
        {
            e.printStackTrace();
        }
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals(name))
                {
                    cookie.setValue(value);
                    cookie.setPath("/");
                    cookie.setMaxAge(2592000);
                    response.addCookie(cookie);
                    break;
                }
            }
        }
    }

    public static void delCookie(HttpServletRequest request, HttpServletResponse response, String name)
    {
        if (name == null) {
            return;
        }
        try
        {
            name = URLEncoder.encode(name, "utf-8");
        }
        catch (UnsupportedEncodingException e)
        {
            e.printStackTrace();
        }
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals(name))
                {
                    cookie.setValue(null);
                    cookie.setMaxAge(0);
                    cookie.setPath("/");
                    response.addCookie(cookie);
                    break;
                }
            }
        }
    }

    public static Cookie getCookieByName(HttpServletRequest request, String name)
    {
        try
        {
            name = URLEncoder.encode(name, "utf-8");
        }
        catch (UnsupportedEncodingException e)
        {
            e.printStackTrace();
        }
        Map<String, Cookie> cookieMap = ReadCookieMap(request);
        if (cookieMap.containsKey(name))
        {
            Cookie cookie = (Cookie)cookieMap.get(name);
            return cookie;
        }
        return null;
    }

    public static String getCookieValue(HttpServletRequest request, String name)
    {
        Cookie cookie = getCookieByName(request, name);
        if (cookie != null) {
            return cookie.getValue();
        }
        return "";
    }

    private static Map<String, Cookie> ReadCookieMap(HttpServletRequest request)
    {
        Map<String, Cookie> cookieMap = new HashMap();
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                cookieMap.put(cookie.getName(), cookie);
            }
        }
        return cookieMap;
    }

    public static String getCookie(String cookieName, HttpServletRequest request)
    {
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals(cookieName)) {
                    return cookie.getValue();
                }
            }
        }
        return null;
    }
}
