package cn.xdf.config;

import cn.xdf.login.service.IPreLoginHandler;
import com.alibaba.fastjson.parser.ParserConfig;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.springframework.context.ResourceLoaderAware;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * @author liupeng
 * @date 2020/7/31-15:25
 **/
public class ConfigMssage  implements ResourceLoaderAware {
    public static final String CURRENT_USER = "current_user";
    private int tokenTimeOut = 30;
    private int aotologininExpDays;
    public static final String SESSION_ATTR_NAME = "";
    public Boolean isSecureMode;
    private ResourceLoader resourceLoader;
    private IPreLoginHandler preLoginHandler;
    private List<SubSystem> subSystems = new ArrayList();
    private String loginViewName = "index";

    public String getLoginViewName()
    {
        return this.loginViewName;
    }

    public void setLoginViewName(String loginViewName)
    {
        this.loginViewName = loginViewName;
    }

    public int getTokenTimeOut()
    {
        return this.tokenTimeOut;
    }

    public void setTokenTimeOut(int tokenTimeOut)
    {
        this.tokenTimeOut = tokenTimeOut;
    }

    public List<SubSystem> getSubSystems()
    {
        return this.subSystems;
    }

    public void setSubSystems(List<SubSystem> subSystems)
    {
        this.subSystems = subSystems;
    }

    public String getProperties(String key)
    {
        Properties configProperties = new Properties();
        try
        {
            Resource resource = this.resourceLoader.getResource("classpath:config.properties");
            configProperties.load(resource.getInputStream());
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
        String valStr = configProperties.getProperty(key);
        return valStr;
    }

    public void refreshConfig()
    {
        ParserConfig.getGlobalInstance().addAccept("com.taobao.pac.client.sdk.dataobject.");
        ParserConfig.getGlobalInstance().setAutoTypeSupport(true);
        this.tokenTimeOut = Integer.parseInt(getProperties("tokenTimeOut"));
        loadSubSystem();
    }

    public void destroy()
    {
        for (SubSystem subSystem : this.subSystems) {
            subSystem.noticeShutDown();
        }
    }

    private void loadSubSystem()
    {
        try
        {
            Resource resource = this.resourceLoader.getResource("classpath:subSystem.xml");
            SAXReader saxReader = new SAXReader();
            Document document = saxReader.read(resource.getInputStream());
            Element rootElement = document.getRootElement();
            List<Element> elements = rootElement.elements();
            this.subSystems.clear();
            for (Element element : elements)
            {
                SubSystem subSystem = new SubSystem();
                subSystem.setId(element.attributeValue("id"));
                subSystem.setName(element.attributeValue("name"));
                subSystem.setBaseUrl(element.elementText("baseUrl"));
                subSystem.setHomeUrl(element.elementText("homeUrl"));
                subSystem.setInnerAddress(element.elementText("innerAddress"));
                this.subSystems.add(subSystem);
            }
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    public void setResourceLoader(ResourceLoader resourceLoader)
    {
        this.resourceLoader = resourceLoader;
    }

    public IPreLoginHandler getPreLoginHandler()
    {
        return this.preLoginHandler;
    }

    public void setPreLoginHandler(IPreLoginHandler preLoginHandler)
    {
        this.preLoginHandler = preLoginHandler;
    }

    public int getAotologininExpDays()
    {
        return this.aotologininExpDays;
    }

    public void setAotologininExpDays(int aotologininExpDays)
    {
        this.aotologininExpDays = aotologininExpDays;
    }

    public Boolean getSecureMode()
    {
        return this.isSecureMode;
    }

    public void setSecureMode(Boolean secureMode)
    {
        this.isSecureMode = secureMode;
    }
}
