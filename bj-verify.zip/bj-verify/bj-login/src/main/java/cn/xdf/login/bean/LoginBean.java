package cn.xdf.login.bean;

import cn.xdf.framework.annotation.Column;
import cn.xdf.framework.annotation.Id;
import cn.xdf.framework.annotation.Table;

import java.util.Date;

/**
 * @author liupeng
 * @date 2020/7/31-16:32
 **/

@Table(name="bj_tb_login")
public class LoginBean {
    @Id
    @Column(name = "loginId")
    private String id;
    private String userLoginId;
    @Column(name = "userId")
    private String userId;
    private String userName;
    private String passWord;
    private String mobile;
    private Date createTime;
    private Date lastLoginTime;
    private String targetUrl;

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserName() {
        return this.userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassWord() {
        return this.passWord;
    }

    public void setPassWord(String passWord) {
        this.passWord = passWord;
    }

    public String getMobile() {
        return this.mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public Date getCreateTime() {
        return this.createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getLastLoginTime() {
        return this.lastLoginTime;
    }

    public void setLastLoginTime(Date lastLoginTime) {
        this.lastLoginTime = lastLoginTime;
    }

    public String getTargetUrl() {
        return this.targetUrl;
    }

    public void setTargetUrl(String targetUrl) {
        this.targetUrl = targetUrl;
    }

    public String getUserId() {
        return this.userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserLoginId() {
        return this.userLoginId;
    }

    public void setUserLoginId(String userLoginId) {
        this.userLoginId = userLoginId;
    }
}