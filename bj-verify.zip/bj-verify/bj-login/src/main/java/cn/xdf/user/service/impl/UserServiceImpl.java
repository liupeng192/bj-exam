package cn.xdf.user.service.impl;

import cn.xdf.user.bean.UserInfo;
import cn.xdf.user.dao.UserDao;
import cn.xdf.user.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author liupeng
 * @date 2020/7/31-17:15
 **/
@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserDao userDao;

    public UserInfo getUserInfo(UserInfo userInfo) {
        return this.userDao.getUserInfo(userInfo);
    }

    public void addUserInfo(UserInfo userInfo) {
        this.userDao.save(userInfo);
    }
}
