package cn.xdf.token;

import cn.xdf.config.ConfigMssage;
import cn.xdf.config.SubSystem;
import cn.xdf.rmi.data.U2AccessTokenDto;
import cn.xdf.utils.RedisUtils;
import cn.xdf.utils.SpringUtils;
import cn.xdf.utils.StringUtils;
import com.alibaba.fastjson.JSON;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author liupeng
 * @date 2020/7/31-16:10
 **/
public class TokenManger {
    private static final Timer timer = new Timer(true);
    public static Map<String, Token> DATA_MAP = new ConcurrentHashMap();
    private static final ConfigMssage config = (ConfigMssage) SpringUtils.getInstance(ConfigMssage.class);
    private static final String SSO_TOKE_KEY = "sso_toke_table";
    @Autowired
    private static ConfigMssage configMssage;

    public static U2AccessTokenDto validate(String tokenKey)
    {
        String stk = (String) RedisUtils.getObj(tokenKey);
        Token tk = (Token) JSON.parseObject(stk, Token.class);
        return tk != null ? tk.getU2AccessToken() : null;
    }

    public static void addToken(String tokenKey, U2AccessTokenDto u2AccessToken)
    {
        Token token = new Token(u2AccessToken, new Date(new Date().getTime() + config.getTokenTimeOut() * 60 * 1000));
        RedisUtils.setforValToString("sso_toke_table", tokenKey);
        RedisUtils.set(tokenKey, JSON.toJSONString(token));
    }

    static
    {
        timer.schedule(new TimerTask()
        {
            public void run()
            {
                Set<String> valSets = RedisUtils.getforValToString("sso_toke_table");
                if ((valSets != null) && (!valSets.isEmpty())) {
                    for (String tokenKey : valSets)
                    {
                        String tokenStr = (String)RedisUtils.getObj(tokenKey);
                        if (StringUtils.isEmpty(tokenStr)) {
                            break;
                        }
                        Token token = (Token)JSON.parseObject(tokenStr, Token.class);
                        Date expired = token.getTokenExpireTime();
                        Date now = new Date();
                        if (now.compareTo(expired) > 0)
                        {
                            List<SubSystem> subSystems = TokenManger.config.getSubSystems();
                            Date maxSubsytemExpired = expired;
                            for (SubSystem subSystem : subSystems)
                            {
                                Date subSystemExpired = subSystem.noticeTimeout(tokenKey, TokenManger.config.getTokenTimeOut());
                                if ((subSystemExpired != null) && (subSystemExpired.compareTo(now) > 1)) {
                                    maxSubsytemExpired = maxSubsytemExpired.compareTo(subSystemExpired) > 0 ? maxSubsytemExpired : subSystemExpired;
                                }
                            }
                            if (maxSubsytemExpired.compareTo(now) > 0) {
                                token.setTokenExpireTime(maxSubsytemExpired);
                            } else {
                                RedisUtils.del(new String[] { tokenKey });
                            }
                        }
                    }
                }
            }
        }, 60000L, 60000L);
    }

    public static void invlid(String token)
    {
        if (token != null) {
            DATA_MAP.remove(token);
        }
    }
}
