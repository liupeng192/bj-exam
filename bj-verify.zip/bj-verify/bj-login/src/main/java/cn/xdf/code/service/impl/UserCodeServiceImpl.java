package cn.xdf.code.service.impl;

import cn.xdf.code.bean.ConfirmCode;
import cn.xdf.code.bean.UserCode;
import cn.xdf.code.dao.ConfirmCodeDao;
import cn.xdf.code.dao.UserCodeDao;
import cn.xdf.code.service.UserCodeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author liupeng
 * @date 2020/7/31-17:39
 **/

@Service
public class UserCodeServiceImpl  implements UserCodeService
{
    @Autowired
    private UserCodeDao userCodeDao;
    @Autowired
    private ConfirmCodeDao confirmCodeDao;

    public void addUserCode(UserCode userCode)
    {
        this.userCodeDao.save(userCode);
    }

    public void addConfimCode(ConfirmCode confirmCode)
    {
        this.confirmCodeDao.save(confirmCode);
    }

    public List<UserCode> queryUserCodes(UserCode userCode)
    {
        return this.userCodeDao.getUserCodes(userCode);
    }
}