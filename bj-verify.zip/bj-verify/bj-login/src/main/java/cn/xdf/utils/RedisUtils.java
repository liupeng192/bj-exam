package cn.xdf.utils;

import com.alibaba.fastjson.support.spring.FastJsonRedisSerializer;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.SessionCallback;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import java.util.*;
import java.util.concurrent.TimeUnit;

public final class RedisUtils {

	private static RedisTemplate<String, Object> redisTemplate = SpringUtils.getInstance("redisTemplate"); 
	private static StringRedisSerializer keySerializer = new StringRedisSerializer();
	private static FastJsonRedisSerializer<?> valueSerializer = new FastJsonRedisSerializer<Object>(Object.class);
	
	static{
		redisTemplate.setKeySerializer(keySerializer);
		redisTemplate.setValueSerializer(valueSerializer);
		
		redisTemplate.setHashKeySerializer(keySerializer);
		redisTemplate.setHashValueSerializer(valueSerializer);
	}
	
	/** 
     * 写入缓存 
     *  
     * @param key 
     * @param value 
     * @param expire 
     */  
    public static void set(final String key, final Object value, final long expire) {  
        redisTemplate.opsForValue().set(key, value,expire,TimeUnit.SECONDS);  
    }
    
    /** 
     * 写入缓存 
     *  
     * @param key 
     * @param value
     */  
    public static void set(final String key, final Object value) {  
        redisTemplate.opsForValue().set(key, value);   
    } 
  
    /** 
     * 读取缓存 
     *  
     * @param key 
     * @param clazz 
     * @return 
     */  
    @SuppressWarnings("unchecked")  
    public static <T> T get(final String key, Class<T> clazz) {  
        return (T) redisTemplate.boundValueOps(key).get();  
    }  
      
    /** 
     * 读取缓存 
     * @param key 
     * @return 
     */  
    public static Object getObj(final String key){  
        return redisTemplate.boundValueOps(key).get();  
    }  
  
    /** 
     * 删除，根据key精确匹配 
     *  
     * @param key 
     */  
    public static void del(final String... key) {  
        redisTemplate.delete(Arrays.asList(key));  
    }  
  
    /** 
     * 批量删除，根据key模糊匹配 
     *  
     * @param pattern 
     */  
    public static void delpn(final String... pattern) {  
        for (String kp : pattern) {  
            redisTemplate.delete(redisTemplate.keys(kp + "*"));  
        }  
    }  
  
    /** 
     * key是否存在 
     *  
     * @param key 
     */  
    public static boolean exists(final String key) {  
        return redisTemplate.hasKey(key);  
    }  
    
    /** 
     * 写入缓存 
     *  
     * @param key 
     * @param expireTime
     * @return 
     */  
    public static boolean expire(final String key, Long expireTime) {  
        boolean result = false;  
        try {  
            redisTemplate.expire(key, expireTime, TimeUnit.SECONDS);  
            result = true;  
        } catch (Exception e) {  
            Log.error(e.getMessage(), e);   
        }  
        return result;  
    }
    
    /**
	 * 批量查询
	 * @param keys
	 * @return
	 */
	public static List<Object> batchGet(List<String> keys) {
		List<Object> list = new ArrayList<>();
		
		List<Object> rawList = redisTemplate.executePipelined(new SessionCallback<Object>() {

			@Override
			@SuppressWarnings("rawtypes")
			public Object execute(RedisOperations operations) throws DataAccessException {
				keys.forEach(key -> {
					operations.opsForValue().get(key);
				});
				return null;
			}
			
		});
		
		rawList.stream().forEach(item -> {
			if(item != null) {
				list.add(item);
			}
		});
		
		return list;
	}
	
	/**
	 * 批量查询
	 * @param keys
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> List<T> batchGet(List<String> keys,Class<T> clazz) {
		List<Object> list = redisTemplate.executePipelined(new SessionCallback<Object>() {

			@Override
			@SuppressWarnings("rawtypes")
			public Object execute(RedisOperations operations) throws DataAccessException {
				keys.forEach(key -> {
					operations.opsForValue().get(key);
				});
				return null;
			}
			
		});
		 
		return (ArrayList<T>)list;
	}
    
    /**
     * redis对hash的操作
     * @author luanhaibin
     *
     */
    public static class hash {
    	/**
         * 存入hashmap
         * @param key
         * @param hashKey
         * @param value
         */
        public static void put(String key,Object hashKey,Object value) {
    		redisTemplate.opsForHash().put(key, hashKey, value);
    	}
    	
        /**
         * 存入hashmap
         * @param key
         * @param value
         */
    	public static void putAll(String key,Map<Object,Object> value) {
    		redisTemplate.opsForHash().putAll(key,value);
    	}
    	
    	
    	/**
    	 * 存入hashmap
    	 * @param key
    	 * @param value
    	 * @param expireTime
    	 */
    	public static void putAll(final String key,final Map<Object,Object> value,final Long expireTime) {
    		redisTemplate.execute(new SessionCallback<List<Object>>(){
        		
				@Override
				@SuppressWarnings({ "unchecked", "rawtypes" })
    			public List<Object> execute(RedisOperations operations) throws DataAccessException {
    				operations.multi();
    				operations.opsForHash().putAll(key,value);
    				operations.expire(key,expireTime,TimeUnit.SECONDS);
    				List list = operations.exec();
    				return list;
    			}
        		
    		});
    		
    	}

    	/**
    	 * 查询
    	 * @param key
    	 * @return
    	 */
    	public static Map<Object,Object> get(String key) {
    		return redisTemplate.opsForHash().entries(key);
    	}

		/**
		 * 查询
		 * @param key
		 * @param field
		 * @return
		 */
		public static Object get(String key,Object field) {
			return redisTemplate.opsForHash().get(key,field);
		}

		/**
		 * 删除
		 * @param key
		 * @param field
		 * @return
		 */
		public static void del(String key,Object field) {
			redisTemplate.opsForHash().delete(key,field);
		}


    	
    	/**
    	 * 批量查询
    	 * @param keys
    	 * @return
    	 */
    	@SuppressWarnings({ "unchecked", "rawtypes" })
		public static List<Object> batchGet(List<String> keys) {
    		List<Object> list = new ArrayList<>();
    		
    		List<Object> rawList = redisTemplate.executePipelined(new SessionCallback<Object>() {

				@Override
				public Object execute(RedisOperations operations) throws DataAccessException {
					keys.forEach(key -> {
						operations.opsForHash().entries(key);
    				});
					return null;
				}
    			
    		});
    		
    		rawList.stream().forEach(item -> {
    			if(item != null) {
    				if(item instanceof Map) {
    					Map map = (Map)item;
    					if(map.keySet().size() > 0) {
    						list.add(item);
    					}
    				}
    			}
    		});
    		
    		return list;
    	}
    	
    	/**
    	 * 批量查询
    	 * @param keys
    	 * @return
    	 */
    	@SuppressWarnings({ "unchecked", "rawtypes" })
		public static <T> List<T> batchGet(List<String> keys,Class<T> clazz) {
    		List<Object> list = new ArrayList<>();
    		
    		List<Object> rawList = redisTemplate.executePipelined(new SessionCallback<Object>() {

				@Override
				public <K, V> Object execute(RedisOperations<K, V> operations) throws DataAccessException {
					keys.forEach(key -> {
						operations.opsForHash().entries((K)key);
    				});
					return null;
				}
    			
    		});
    		
    		rawList.stream().forEach(item -> {
    			if(item != null) {
    				if(item instanceof Map) {
    					Map map = (Map)item;
    					if(map.keySet().size() > 0) {
    						list.add(item);
    					}
    				}
    			}
    		});
    		
    		return (ArrayList<T>)list;
    		
    	}
    }
	
    /** 
     * 尝试获得分布式锁
     *  
     * @param key 
     * @param value 
     * @return 
     */  
    public static boolean tryLock(final String lockKey, final String value,final Long expireTime) {
    	boolean success = false;
    	
    	List<Object> list = redisTemplate.execute(new SessionCallback<List<Object>>(){
    		
    		@Override
			@SuppressWarnings({ "rawtypes", "unchecked" })
			public List<Object> execute(RedisOperations operations) throws DataAccessException {
				operations.multi();
				operations.opsForValue().setIfAbsent(lockKey,value);
				operations.expire(lockKey, expireTime,TimeUnit.SECONDS);
				List list = operations.exec();
				return list;
			}
    		
		});
    	
    	if(CollectionUtils.isNotEmpty(list)) {
    		success = (Boolean)list.get(0);
    	}
    	
    	return success;
    }
    
    /**
     * 释放分布式锁
     * @param lockKey
     * @return
     */
    public static void releaseLock(final String lockKey,final String value) {  
    	Object _value = redisTemplate.opsForValue().get(lockKey);
    	if(_value != null && _value.toString().equals(value)) { 
    		redisTemplate.delete(lockKey);
		}
    }
	/**
	 * 读取缓存
	 * @param key
	 * @return
	 */
	public static Set getforValToString(String key){
		return redisTemplate.opsForSet().members(key);
	}

	/**
	 * 存入缓存
	 * @param key
	 * @param value
	 */
	public static void setforValToString(String key ,String value){
		redisTemplate.opsForSet().add(key,value);
	}

}