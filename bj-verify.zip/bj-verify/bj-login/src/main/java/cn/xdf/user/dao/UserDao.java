package cn.xdf.user.dao;

import cn.xdf.framework.dao.BaseDao;
import cn.xdf.user.bean.UserInfo;
import cn.xdf.utils.StringUtils;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

/**
 * @author liupeng
 * @date 2020/7/31-17:15
 **/
@Repository
public class UserDao extends BaseDao<UserInfo> {
    public UserInfo getUserInfo(UserInfo user)
    {
        String sql = " select userID as id,xdfUserID,userName,`passWord`,nickName,email,mobile,flagModify FROM bj_tb_user WHERE 1 = 1 ";

        List<Object> args = new ArrayList();
        if (StringUtils.isNotBlank(user.getUserName()))
        {
            sql = sql + "AND userName = ? ";
            args.add(user.getUserName());
        }
        else if (StringUtils.isNotBlank(user.getMobile()))
        {
            sql = sql + "AND mobile = ? ";
            args.add(user.getMobile());
        }
        sql = sql + "ORDER BY createTime desc";
        return (UserInfo)super.queryForObject(sql, args.toArray(new Object[args.size()]));
    }
}
